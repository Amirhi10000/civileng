#!/usr/bin/env node
// Pre-registered Go/No-Go on HELD-OUT speakers, judged on the UPPER confidence bound of each error rate.
// Usage: node tools/go-nogo.mjs labeled.json docs/go-no-go-criteria.json docs/preregistration.json
// (kappa and exclusion rate are read from labeled.meta.json, written by merge-labels — never typed by hand.)
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { decide } from '../src/core.js';
import { splitBySpeaker, leaveOneSpeakerOut } from './calibrate.mjs';
import { criteriaHash, missingCriteria, invalidCriteria, anchorOf } from './preregister.mjs';

// Exact (Clopper–Pearson) one-sided upper bound for a binomial proportion: P(X ≤ k | n, p) = 1 − confidence.
export function clopperPearsonUpper(k, n, confidence = 0.95) {
  if (n <= 0 || k >= n) return 1;
  const lf = [0]; for (let i = 1; i <= n; i++) lf[i] = lf[i - 1] + Math.log(i);
  const cdf = p => { let s = 0; for (let i = 0; i <= k; i++) s += Math.exp(lf[n] - lf[i] - lf[n - i] + i * Math.log(p) + (n - i) * Math.log(1 - p)); return s; };
  let lo = 1e-12, hi = 1 - 1e-12;
  for (let it = 0; it < 80; it++) { const mid = (lo + hi) / 2; if (cdf(mid) > 1 - confidence) lo = mid; else hi = mid; }
  return (lo + hi) / 2;
}

// Recordings of one speaker are not independent, so the naive bound is optimistic. Resample SPEAKERS (clusters)
// instead of recordings. With very few speakers even this is optimistic → the verdict takes the largest of three
// bounds, and minTestSpeakers / a high confidence must be pre-registered.
function mulberry32(a) { return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
export function clusterBootstrapUpper(bySpeaker, confidence = 0.95, { B = 4000, seed = 12345 } = {}) {
  const cl = [...bySpeaker.values()].filter(c => c.n > 0);
  if (cl.length < 2) return 1;
  const rnd = mulberry32(seed), stats = [];
  for (let b = 0; b < B; b++) { let k = 0, n = 0; for (let i = 0; i < cl.length; i++) { const c = cl[Math.floor(rnd() * cl.length)]; k += c.k; n += c.n; } stats.push(k / n); }
  stats.sort((a, b) => a - b);
  return stats[Math.min(B - 1, Math.ceil(confidence * B) - 1)];
}
// One-sided t upper bound on the mean of per-speaker rates (speakers are the independent units). Student-t quantile via Cornish–Fisher.
// EXACT Student-t quantile (regularized incomplete beta + bisection). The earlier polynomial approximation was ~27 % too low at df=1.
function lgamma(x) {
  const c = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  let y = x, tmp = x + 5.5, ser = 1.000000000190015;
  tmp -= (x + 0.5) * Math.log(tmp);
  for (let j = 0; j < 6; j++) ser += c[j] / ++y;
  return -tmp + Math.log(2.5066282746310005 * ser / x);
}
function betacf(a, b, x) {
  const FPMIN = 1e-300, qab = a + b, qap = a + 1, qam = a - 1;
  let c = 1, d = 1 - qab * x / qap; if (Math.abs(d) < FPMIN) d = FPMIN; d = 1 / d;
  let h = d;
  for (let m = 1; m <= 300; m++) {
    const m2 = 2 * m;
    let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
    d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN; c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN; d = 1 / d; h *= d * c;
    aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
    d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN; c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN; d = 1 / d;
    const del = d * c; h *= del;
    if (Math.abs(del - 1) < 3e-14) break;
  }
  return h;
}
function ibeta(x, a, b) {
  if (x <= 0) return 0; if (x >= 1) return 1;
  const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  return x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b;
}
const tCdf = (t, df) => { const p = 0.5 * ibeta(df / (df + t * t), df / 2, 0.5); return t > 0 ? 1 - p : p; };
export const tQuantile = (q, df) => { let lo = 0, hi = 1e6; if (q < 0.5) return -tQuantile(1 - q, df); for (let i = 0; i < 200; i++) { const m = (lo + hi) / 2; tCdf(m, df) < q ? lo = m : hi = m; } return (lo + hi) / 2; };
export function speakerTUpper(bySpeaker, confidence = 0.95) {
  const r = [...bySpeaker.values()].filter(c => c.n > 0).map(c => c.k / c.n), S = r.length;
  if (S < 2) return 1;
  const m = r.reduce((a, b) => a + b, 0) / S, sd = Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / (S - 1));
  return Math.min(1, m + tQuantile(confidence, S - 1) * sd / Math.sqrt(S));
}
// Verdict bound = the largest of: naive exact, speaker-level t, speaker-resampling bootstrap.
// Simulation (README): this narrows but does NOT remove the optimism when a few speakers dominate the errors.
export const robustUpper = (bySpeaker, confidence) => {
  let k = 0, n = 0; for (const c of bySpeaker.values()) { k += c.k; n += c.n; }
  return Math.max(clopperPearsonUpper(k, n, confidence), speakerTUpper(bySpeaker, confidence), clusterBootstrapUpper(bySpeaker, confidence));
};

// Warnings (not errors): is the pre-registration anchored outside this machine?
export function anchorWarnings(prereg, { critPath, expectedAnchor } = {}) {
  const w = [];
  if (anchorOf(prereg) !== prereg.anchor) w.push('preregistration.json anchor does not match its own fields (edited?)');
  if (expectedAnchor && expectedAnchor !== anchorOf(prereg)) w.push('anchor differs from the externally stored value — pre-registration was altered');
  if (!expectedAnchor) w.push('no external anchor supplied (--anchor): pre-registration is only as trustworthy as this machine');
  if (!prereg.git) w.push('no git commit recorded');
  else if (critPath) {
    try {
      const committed = execFileSync('git', ['show', `${prereg.git}:${critPath}`], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
      if (criteriaHash(JSON.parse(committed)) !== prereg.criteriaSha256) w.push('criteria at the recorded git commit differ from the pre-registered hash');
    } catch { w.push('could not verify criteria at the recorded git commit'); }
  }
  return w;
}

export function checkPreregistration(crit, prereg, rows) {
  const problems = [];
  if (criteriaHash(crit) !== prereg?.criteriaSha256) problems.push('criteria file differs from the pre-registered hash');
  const first = rows.map(r => r.recordedAt).filter(Boolean).sort()[0];
  if (!first) problems.push('rows have no recordedAt');
  else if (first < prereg.registeredAt) problems.push('data was recorded BEFORE the pre-registration');
  if (rows.some(r => r.preregSha256 !== prereg?.criteriaSha256)) problems.push('some rows were collected under a different pre-registration');
  return problems;
}

// Lower bounds mirror the upper ones (needed to call NO-GO only when failure is clear, not merely uncertain).
export const clopperPearsonLower = (k, n, confidence = 0.95) => (n <= 0 ? 0 : 1 - clopperPearsonUpper(n - k, n, confidence));
export function speakerTLower(bySpeaker, confidence = 0.95) {
  const r = [...bySpeaker.values()].filter(c => c.n > 0).map(c => c.k / c.n), S = r.length;
  if (S < 2) return 0;
  const m = r.reduce((a, b) => a + b, 0) / S, sd = Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / (S - 1));
  return Math.max(0, m - tQuantile(confidence, S - 1) * sd / Math.sqrt(S));
}
const totals = m => [...m.values()].reduce((a, c) => ({ k: a.k + c.k, n: a.n + c.n }), { k: 0, n: 0 });
const robustLower = (m, conf) => { const t = totals(m); return Math.min(clopperPearsonLower(t.k, t.n, conf), speakerTLower(m, conf)); };

// Anchor problems that must stop the run under --require-anchor ("no git commit" is only a warning).
export const blockingAnchorProblems = w => w.filter(x => !/no git commit/.test(x));

// mode: 'split' (fixed thresholds from data/thresholds.json on a speaker-disjoint test part) or 'loso' (leave-one-speaker-out).
// Verdicts: GO (all pre-registered checks pass), NO-GO (enough speakers/samples AND labels trustworthy AND the error rate is
// CLEARLY above its limit: the LOWER bound exceeds it), otherwise INCONCLUSIVE ("not enough information", which is not "bad performance").
export function goNoGo(rows, crit, meta, cfg, prereg, { mode = 'split' } = {}) {
  const miss = missingCriteria(crit), bad = invalidCriteria(crit);
  if (miss.length) throw new Error('criteria not pre-registered: ' + miss.join(', '));
  if (bad.length) throw new Error('invalid criteria: ' + bad.join('; '));
  const problems = checkPreregistration(crit, prereg, rows);
  if (problems.length) throw new Error('pre-registration check failed: ' + problems.join('; '));

  let fr = new Map(), fa = new Map(), thresholdsUsed = cfg, nSpeakersEvaluated;
  if (mode === 'loso') {
    const l = leaveOneSpeakerOut(rows); fr = l.fr; fa = l.fa; nSpeakersEvaluated = l.speakers;
    thresholdsUsed = { perFold: l.chosenThresholds.length, passScoreRange: [Math.min(...l.chosenThresholds.map(c => c.passScore)), Math.max(...l.chosenThresholds.map(c => c.passScore))] };
  } else {
    const { test, testSpeakers } = splitBySpeaker(rows); nSpeakersEvaluated = testSpeakers.length;
    for (const r of test) {
      const pass = decide(r.phonemes, cfg).correct, truth = r.label === 'correct', map = truth ? fr : fa;
      const c = map.get(r.speaker) ?? { k: 0, n: 0 }; c.n++; if (truth ? !pass : pass) c.k++; map.set(r.speaker, c);
    }
  }
  const T = { fr: totals(fr), fa: totals(fa) };
  const frrUpper = robustUpper(fr, crit.confidence), faUpper = robustUpper(fa, crit.confidence);
  const frrLower = robustLower(fr, crit.confidence), faLower = robustLower(fa, crit.confidence);
  const sufficiency = {
    speakers: new Set(rows.map(r => r.speaker)).size >= crit.minSpeakers,
    testSpeakers: nSpeakersEvaluated >= crit.minTestSpeakers,
    testCorrect: T.fr.n >= crit.minTestCorrect, testIncorrect: T.fa.n >= crit.minTestIncorrect,
  };
  const labelQuality = { kappa: meta.kappa >= crit.minKappa, excludedFraction: meta.excludedFraction <= crit.maxExcludedFraction };
  const rates = { falseRejectUpper: frrUpper <= crit.maxFalseRejectRate, falseAcceptUpper: faUpper <= crit.maxFalseAcceptRate };
  const labelsOk = Object.values(labelQuality).every(Boolean);
  const sufficient = Object.values(sufficiency).every(Boolean);
  const clearlyBad = sufficient && labelsOk && (frrLower > crit.maxFalseRejectRate || faLower > crit.maxFalseAcceptRate);
  const allPass = [sufficiency, labelQuality, rates].every(o => Object.values(o).every(Boolean));
  const reasons = Object.entries({ ...sufficiency, ...labelQuality, ...rates }).filter(([, ok]) => !ok).map(([k]) => k);
  return {
    verdict: clearlyBad ? 'NO-GO' : allPass ? 'GO' : 'INCONCLUSIVE', mode, failedChecks: reasons,
    checks: { ...sufficiency, ...labelQuality, ...rates },
    heldOut: { fr: T.fr.k, fa: T.fa.k, pos: T.fr.n, neg: T.fa.n, speakersEvaluated: nSpeakersEvaluated,
               frrUpper: +frrUpper.toFixed(3), faUpper: +faUpper.toFixed(3), frrLower: +frrLower.toFixed(3), faLower: +faLower.toFixed(3) },
    thresholdsUsed, kappa: meta.kappa, excludedFraction: meta.excludedFraction,
  };
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const args = process.argv.slice(2), ai = args.indexOf('--anchor'), anchor = ai >= 0 ? args.splice(ai, 2)[1] : null;
  const requireAnchor = args.includes('--require-anchor'), loso = args.includes('--loso');
  for (const f of ['--require-anchor', '--loso']) { const i = args.indexOf(f); if (i >= 0) args.splice(i, 1); }
  const [d, c, p] = args;
  if (!p) { console.error('usage: go-nogo.mjs labeled.json criteria.json preregistration.json [--anchor <value>] [--require-anchor] [--loso]'); process.exit(2); }
  const cfg = JSON.parse(readFileSync(new URL('../data/thresholds.json', import.meta.url), 'utf8'));
  const meta = JSON.parse(readFileSync(d.replace(/\.json$/, '.meta.json'), 'utf8'));
  const [rows, crit, prereg] = [d, c, p].map(f => JSON.parse(readFileSync(f, 'utf8')));
  const warnings = anchorWarnings(prereg, { critPath: c.replace(/^.*?(docs\/)/, '$1'), expectedAnchor: anchor });
  if (requireAnchor && blockingAnchorProblems(warnings).length) { console.error('STOP (--require-anchor):\n- ' + blockingAnchorProblems(warnings).join('\n- ')); process.exit(1); }
  const result = goNoGo(rows, crit, meta, cfg, prereg, { mode: loso ? 'loso' : 'split' });
  result.warnings = warnings;
  console.log(JSON.stringify(result, null, 2));
}
