#!/usr/bin/env node
// Merge two blind raters' labels into calibration rows.
// Usage: node tools/merge-labels.mjs collected.json rater1.json rater2.json out.json
// Rater files: [{ id, rater, label: "correct"|"incorrect"|"unsure" }]. Rows with disagreement/unsure are dropped (and counted).
import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

export function cohenKappa(a, b) {
  const labels = [...new Set([...a, ...b])], n = a.length;
  if (!n) return NaN;
  const po = a.filter((x, i) => x === b[i]).length / n;
  const pe = labels.reduce((s, l) => s + (a.filter(x => x === l).length / n) * (b.filter(x => x === l).length / n), 0);
  return pe === 1 ? 1 : (po - pe) / (1 - pe);
}

export function mergeLabels(collected, r1, r2) {
  const m1 = new Map(r1.map(r => [r.id, r.label])), m2 = new Map(r2.map(r => [r.id, r.label]));
  const both = collected.filter(c => m1.has(c.id) && m2.has(c.id));
  const kappa = cohenKappa(both.map(c => m1.get(c.id)), both.map(c => m2.get(c.id)));
  const rows = [], dropped = { disagree: 0, unsure: 0, unrated: collected.length - both.length };
  for (const c of both) {
    const a = m1.get(c.id), b = m2.get(c.id);
    if (a === 'unsure' || b === 'unsure') { dropped.unsure++; continue; }
    if (a !== b) { dropped.disagree++; continue; }
    const { audioPcm16Base64, ...rest } = c;           // calibration rows do not need the audio
    rows.push({ ...rest, label: a });
  }
  const intentMismatch = rows.filter(r => r.intent && r.intent !== r.label).length;
  const excludedFraction = both.length ? (dropped.disagree + dropped.unsure) / both.length : 1;
  return { rows, kappa, dropped, intentMismatch, excludedFraction, total: collected.length };
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const args = process.argv.slice(2), force = args.includes('--force'), minK = Number(args[args.indexOf('--min-kappa') + 1]) || 0.6;
  const [c, a, b, out] = args.filter((x, i) => !x.startsWith('--') && args[i - 1] !== '--min-kappa');
  if (!out) { console.error('usage: merge-labels.mjs collected.json rater1.json rater2.json out.json [--min-kappa 0.6] [--force]'); process.exit(2); }
  const r = mergeLabels(...[c, a, b].map(f => JSON.parse(readFileSync(f, 'utf8'))));
  console.log(`rows kept: ${r.rows.length}/${r.total}, kappa: ${r.kappa.toFixed(2)}, excluded: ${(100 * r.excludedFraction).toFixed(1)}% ${JSON.stringify(r.dropped)}, intent≠label: ${r.intentMismatch}`);
  if (!(r.kappa >= minK) && !force) { console.error(`STOP: kappa < ${minK}. Refine the rating guide and re-rate (override with --force for diagnosis only).`); process.exit(1); }
  writeFileSync(out, JSON.stringify(r.rows, null, 1));
  writeFileSync(out.replace(/\.json$/, '.meta.json'), JSON.stringify({ kappa: r.kappa, excludedFraction: r.excludedFraction, kept: r.rows.length, total: r.total, dropped: r.dropped, intentMismatch: r.intentMismatch }, null, 1));
}
