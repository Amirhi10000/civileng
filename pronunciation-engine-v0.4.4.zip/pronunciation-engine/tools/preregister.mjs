#!/usr/bin/env node
// Locks the Go/No-Go criteria BEFORE data collection: writes docs/preregistration.json (hash, time, git commit).
// Usage: node tools/preregister.mjs [docs/go-no-go-criteria.json]
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

export const REQUIRED = ['minSpeakers', 'minTestSpeakers', 'minTestCorrect', 'minTestIncorrect', 'minKappa', 'maxExcludedFraction', 'confidence', 'maxFalseRejectRate', 'maxFalseAcceptRate'];
export const canonical = c => JSON.stringify(Object.fromEntries(Object.entries(c).filter(([k]) => !k.startsWith('_')).sort(([a], [b]) => (a < b ? -1 : 1))));
export const criteriaHash = c => createHash('sha256').update(canonical(c)).digest('hex');
export function missingCriteria(c) { return REQUIRED.filter(k => typeof c[k] !== 'number' || Number.isNaN(c[k])); }
const RANGES = { confidence: [0.5, 0.9999], maxFalseRejectRate: [0, 1], maxFalseAcceptRate: [0, 1], maxExcludedFraction: [0, 1], minKappa: [-1, 1] };
const COUNTS = ['minSpeakers', 'minTestSpeakers', 'minTestCorrect', 'minTestIncorrect'];
// Values that are numbers but make no sense (confidence 95 instead of 0.95, negative counts, …).
export function invalidCriteria(c) {
  const bad = [];
  for (const [k, [lo, hi]] of Object.entries(RANGES)) if (typeof c[k] === 'number' && !(c[k] >= lo && c[k] <= hi)) bad.push(`${k} must be in [${lo}, ${hi}] (got ${c[k]})`);
  for (const k of COUNTS) if (typeof c[k] === 'number' && !(Number.isInteger(c[k]) && c[k] >= 1)) bad.push(`${k} must be an integer ≥ 1 (got ${c[k]})`);
  if (typeof c.minTestSpeakers === 'number' && typeof c.minSpeakers === 'number' && c.minTestSpeakers > c.minSpeakers) bad.push('minTestSpeakers cannot exceed minSpeakers');
  return bad;
}
// Tamper-evident anchor: store this string OUTSIDE your own control (push to a remote, email a third party) before collecting data.
export const anchorOf = p => createHash('sha256').update(`${p.criteriaSha256}|${p.registeredAt}|${p.git ?? ''}`).digest('hex');

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const file = process.argv[2] ?? 'docs/go-no-go-criteria.json', crit = JSON.parse(readFileSync(file, 'utf8'));
  const miss = missingCriteria(crit), bad = invalidCriteria(crit);
  if (miss.length || bad.length) { console.error([miss.length && 'fill these criteria first: ' + miss.join(', '), ...bad].filter(Boolean).join('\n')); process.exit(1); }
  let git = null; try { git = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch {}
  const out = { criteriaSha256: criteriaHash(crit), registeredAt: new Date().toISOString(), git };
  out.anchor = anchorOf(out);
  writeFileSync(new URL('../docs/preregistration.json', import.meta.url), JSON.stringify(out, null, 2) + '\n');
  console.log('registered', out);
  console.log('\nNOW store this line somewhere you cannot edit (remote repo push / email to a third party):\n' + out.anchor);
  if (!git) console.warn('WARNING: no git commit recorded — commit the criteria first, so the anchor is verifiable.');
}
