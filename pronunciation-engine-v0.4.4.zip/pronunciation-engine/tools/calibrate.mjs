#!/usr/bin/env node
// Picks decision thresholds from human-labeled recordings.
// Input JSON (export from web/collect.html): [{ label:"correct"|"incorrect", speaker, word, phonemes:[{prob,op}] }]
// Usage: node tools/calibrate.mjs data.json [--cost-fa 1] [--cost-fr 1] [--write]
//   FA = false accept (wrong pronunciation passed), FR = false reject (correct one failed).
//   Learners hate false rejects more than missed errors → default FR cost is 2.
import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { decide } from '../src/core.js';

export function evaluate(rows, cfg) {
  let fa = 0, fr = 0, tp = 0, tn = 0;
  for (const r of rows) {
    const pass = decide(r.phonemes, cfg).correct, truth = r.label === 'correct';
    if (pass && truth) tp++; else if (!pass && !truth) tn++; else if (pass) fa++; else fr++;
  }
  const pos = tp + fr, neg = tn + fa;
  return { fa, fr, tp, tn, far: neg ? fa / neg : 0, frr: pos ? fr / pos : 0 };
}

// Leave-one-speaker-out: thresholds for each speaker are chosen WITHOUT that speaker, then applied to them.
// Pools per-speaker error counts → usable with ~20–25 speakers instead of ~65 for a fixed 70/30 split.
export function leaveOneSpeakerOut(rows, costs = {}) {
  const speakers = [...new Set(rows.map(r => r.speaker))].sort(), fr = new Map(), fa = new Map(), chosen = [];
  for (const sp of speakers) {
    const train = rows.filter(r => r.speaker !== sp), test = rows.filter(r => r.speaker === sp);
    if (!train.some(r => r.label === 'correct') || !train.some(r => r.label === 'incorrect')) continue;
    const { cfg } = calibrate(train, costs); chosen.push(cfg);
    for (const r of test) {
      const pass = decide(r.phonemes, cfg).correct, truth = r.label === 'correct', map = truth ? fr : fa;
      const c = map.get(sp) ?? { k: 0, n: 0 }; c.n++; if (truth ? !pass : pass) c.k++; map.set(sp, c);
    }
  }
  const sum = m => [...m.values()].reduce((a, c) => ({ k: a.k + c.k, n: a.n + c.n }), { k: 0, n: 0 });
  return { fr, fa, speakers: speakers.length, chosenThresholds: chosen, totals: { fr: sum(fr), fa: sum(fa) } };
}

// Deterministic speaker-disjoint split: no speaker ever appears in both train and test.
export function splitBySpeaker(rows, testFraction = 0.3) {
  const speakers = [...new Set(rows.map(r => r.speaker))].sort();
  const h = str => [...str].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const k = Math.max(1, Math.round(speakers.length * testFraction));
  const test = new Set([...speakers].sort((a, b) => h(a) - h(b) || a.localeCompare(b)).slice(0, k));
  return { train: rows.filter(r => !test.has(r.speaker)), test: rows.filter(r => test.has(r.speaker)), testSpeakers: [...test] };
}

export function calibrate(rows, { costFA = 1, costFR = 2 } = {}) {
  if (rows.length < 2 || !rows.some(r => r.label === 'correct') || !rows.some(r => r.label === 'incorrect'))
    throw new Error('need both "correct" and "incorrect" rows');
  let best = null;
  for (let g = 0.4; g <= 0.9001; g += 0.05)
    for (let w = 0.1; w < g - 0.0001; w += 0.05)
      for (let s = 50; s <= 95; s += 5) {
        const cfg = { goodProb: +g.toFixed(2), weakProb: +w.toFixed(2), passScore: s };
        const m = evaluate(rows, cfg), cost = costFA * m.fa + costFR * m.fr;
        if (!best || cost < best.cost) best = { cfg, cost, ...m };
      }
  return best;
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const file = process.argv[2];
  if (!file) { console.error('usage: calibrate.mjs data.json [--cost-fa n] [--cost-fr n] [--write]'); process.exit(2); }
  const num = (n, d) => { const i = process.argv.indexOf(n); return i > 0 ? Number(process.argv[i + 1]) : d; };
  const rows = JSON.parse(readFileSync(file, 'utf8'));
  const speakers = new Set(rows.map(r => r.speaker)).size;
  if (rows.length < 200 || speakers < 10) console.warn(`WARNING: ${rows.length} rows / ${speakers} speakers — too few for reliable thresholds (aim ≥200 rows, ≥10 speakers).`);
  const costs = { costFA: num('--cost-fa', 1), costFR: num('--cost-fr', 2) };
  const { train, test, testSpeakers } = splitBySpeaker(rows, num('--holdout', 0.3));
  if (speakers < 4 || !test.length) { console.error('need ≥ 4 speakers for a speaker-disjoint holdout'); process.exit(1); }
  const b = calibrate(train, costs);
  const held = evaluate(test, b.cfg);
  console.log(JSON.stringify({ chosenOnTrain: b, heldOutSpeakers: testSpeakers, heldOut: held }, null, 2));
  for (const cap of new Set(test.map(r => r.capture ?? 'unknown'))) { const m = evaluate(test.filter(r => (r.capture ?? 'unknown') === cap), b.cfg); console.log(`  capture=${cap}: FAR ${m.far.toFixed(3)} FRR ${m.frr.toFixed(3)} (n=${m.tp + m.tn + m.fa + m.fr})`); }
  console.log(`HELD-OUT (unseen speakers): FAR ${held.far.toFixed(3)}  FRR ${held.frr.toFixed(3)}  — report THESE numbers, not the train ones.`);
  if (process.argv.includes('--write'))
    writeFileSync(new URL('../data/thresholds.json', import.meta.url), JSON.stringify({ ...b.cfg, _status: `calibrated on ${rows.length} rows / ${speakers} speakers; held-out FAR ${held.far.toFixed(3)}, FRR ${held.frr.toFixed(3)}` }, null, 2) + '\n');
}
