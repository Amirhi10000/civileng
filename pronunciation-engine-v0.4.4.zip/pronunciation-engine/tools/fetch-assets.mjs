#!/usr/bin/env node
// Run ONCE on a machine with open internet access; then ship models/ with the app (self-host, no runtime calls).
//   node tools/fetch-assets.mjs            download model files into models/ + write manifest (sha256, bytes)
//   node tools/fetch-assets.mjs --verify   check files on disk against models/manifest.json (use in CI / before release)
import { createHash } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, readFileSync, statSync, writeFileSync, createWriteStream } from 'node:fs';
import { dirname, join } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import { pathToFileURL, fileURLToPath } from 'node:url';

export const MODEL = 'Xenova/wav2vec2-lv-60-espeak-cv-ft';
export const FILES = { required: ['config.json', 'preprocessor_config.json', 'vocab.json', 'onnx/model_quantized.onnx'], optional: ['tokenizer_config.json', 'special_tokens_map.json'] };
const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', 'models');

export function sha256File(p) {
  return new Promise((res, rej) => { const h = createHash('sha256'); createReadStream(p).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej); });
}
export async function verifyManifest(dir = join(ROOT, MODEL), manifest = JSON.parse(readFileSync(join(ROOT, 'manifest.json'), 'utf8'))) {
  const problems = [];
  for (const f of manifest.files) {
    const p = join(dir, f.file);
    if (!existsSync(p)) { problems.push({ file: f.file, problem: 'missing' }); continue; }
    if (statSync(p).size !== f.bytes) problems.push({ file: f.file, problem: 'size mismatch' });
    else if (await sha256File(p) !== f.sha256) problems.push({ file: f.file, problem: 'sha256 mismatch' });
  }
  return problems;
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  if (process.argv.includes('--verify')) {
    const p = await verifyManifest();
    console.log(p.length ? 'PROBLEMS:\n' + JSON.stringify(p, null, 2) : 'assets OK'); process.exit(p.length ? 1 : 0);
  }
  const dir = join(ROOT, MODEL), files = [];
  for (const f of [...FILES.required, ...FILES.optional]) {
    const res = await fetch(`https://huggingface.co/${MODEL}/resolve/main/${f}`);
    if (!res.ok) { if (FILES.required.includes(f)) { console.error(`required file failed: ${f} (${res.status})`); process.exit(1); } continue; }
    mkdirSync(dirname(join(dir, f)), { recursive: true });
    await pipeline(Readable.fromWeb(res.body), createWriteStream(join(dir, f)));
    files.push({ file: f, bytes: statSync(join(dir, f)).size, sha256: await sha256File(join(dir, f)) });
    console.log(f, (files.at(-1).bytes / 1e6).toFixed(1) + ' MB');
  }
  writeFileSync(join(ROOT, 'manifest.json'), JSON.stringify({ model: MODEL, files }, null, 2));
  console.log('total download size: ' + (files.reduce((s, f) => s + f.bytes, 0) / 1e6).toFixed(0) + ' MB  ← decide if this is acceptable for your users');
}
