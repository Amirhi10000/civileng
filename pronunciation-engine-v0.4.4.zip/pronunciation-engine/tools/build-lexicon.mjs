#!/usr/bin/env node
// Builds data/lexicon.json (word → espeak IPA) from the question bank's vocabulary options.
// Usage: node tools/build-lexicon.mjs --bank <bank.json> --out data/lexicon.json [--vocab vocab.json] [--extra words.txt]
// Requires `espeak-ng` on PATH for new words. Existing entries (e.g. hand-corrected) are never overwritten.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { tokenizeIPA } from '../src/core.js';

// Which words are worth pronouncing? Prefer an explicit q.targetWord; else the CORRECT option only,
// and only if it is 1–2 words (distractors and long paraphrases are not pronunciation targets).
export function extractWords(bank, { subjects = ['vocabulary'], maxWords = 2 } = {}) {
  const set = new Set();
  for (const q of bank.questions ?? []) {
    if (!subjects.includes(q.subject)) continue;
    const raw = q.targetWord ?? (q.options ?? []).find(o => o.id === q.correctOptionId)?.text;
    const ws = String(raw ?? '').toLowerCase().match(/[a-z]+(?:'[a-z]+)?/g) ?? [];
    if (ws.length && ws.length <= maxWords) ws.filter(w => w.length > 1).forEach(w => set.add(w));
  }
  return [...set].sort();
}

// American flap [ɾ] is one accepted variant; clear [t]/[d] is another (both intelligible, both taught).
export function expandVariants(word, ipa) {
  if (Array.isArray(ipa) || !ipa.includes('ɾ')) return ipa;
  const alt = ipa.replace(/ɾ/g, /t/.test(word) ? 't' : 'd');
  return alt === ipa ? ipa : [ipa, alt];
}

export function cleanIPA(raw) { return raw.replace(/[\r\n]+/g, ' ').replace(/_/g, '').replace(/\s+/g, ' ').trim(); }

export function espeakIPA(word) {
  return cleanIPA(execFileSync('espeak-ng', ['-q', '--ipa', '-v', 'en-us', word], { encoding: 'utf8' }));
}

export function validateAgainstVocab(lexicon, vocab) {
  const problems = [];
  for (const [w, entry] of Object.entries(lexicon))
    for (const ipa of [entry].flat()) {
      const { dropped } = tokenizeIPA(ipa, vocab);
      if (dropped.length) problems.push({ word: w, ipa, unknownSymbols: dropped });
    }
  return problems;
}

function arg(name) { const i = process.argv.indexOf('--' + name); return i > 0 ? process.argv[i + 1] : null; }

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const bankPath = arg('bank'), out = arg('out') ?? 'data/lexicon.json';
  if (!bankPath) { console.error('missing --bank'); process.exit(2); }
  const words = new Set(extractWords(JSON.parse(readFileSync(bankPath, 'utf8'))));
  if (arg('extra')) readFileSync(arg('extra'), 'utf8').split(/\s+/).filter(Boolean).forEach(w => words.add(w.toLowerCase()));
  const lex = existsSync(out) ? JSON.parse(readFileSync(out, 'utf8')) : {};
  const todo = [...words].filter(w => !(w in lex));
  let missing = [];
  for (const w of todo) {
    try { lex[w] = expandVariants(w, espeakIPA(w)); } catch (e) {
      if (e.code === 'ENOENT') { console.error('espeak-ng not found — install it (apt install espeak-ng / brew install espeak-ng).'); missing = todo; break; }
      missing.push(w);
    }
  }
  const sorted = Object.fromEntries(Object.entries(lex).sort(([a], [b]) => a.localeCompare(b)));
  if (!missing.length || Object.keys(sorted).length) writeFileSync(out, JSON.stringify(sorted, null, 2) + '\n');
  console.log(`${words.size} words, ${Object.keys(sorted).length} in lexicon, ${missing.length} missing`);
  if (arg('vocab')) {
    const probs = validateAgainstVocab(sorted, JSON.parse(readFileSync(arg('vocab'), 'utf8')));
    console.log(probs.length ? 'UNKNOWN SYMBOLS:\n' + JSON.stringify(probs, null, 2) : 'all IPA symbols present in model vocab');
    if (probs.length) process.exitCode = 1;
  }
  if (missing.length) process.exitCode = 1;
}
