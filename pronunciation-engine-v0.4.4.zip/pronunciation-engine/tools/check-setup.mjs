#!/usr/bin/env node
// Release gate: is the offline bundle complete and consistent? Usage: node tools/check-setup.mjs
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { verifyManifest, MODEL } from './fetch-assets.mjs';
import { validateAgainstVocab } from './build-lexicon.mjs';

export async function checkSetup(root, { modelOnly = false } = {}) {
  const problems = [];
  if (!modelOnly) {
    if (!existsSync(join(root, 'vendor/transformers.min.js'))) problems.push('vendor/transformers.min.js missing');
    if (!existsSync(join(root, 'vendor')) || !readdirSync(join(root, 'vendor')).some(f => f.endsWith('.wasm'))) problems.push('no onnxruntime .wasm in vendor/');
  }
  const mf = join(root, 'models/manifest.json');
  if (!existsSync(mf)) problems.push('models/manifest.json missing (run tools/fetch-assets.mjs)');
  else problems.push(...(await verifyManifest(join(root, 'models', MODEL), JSON.parse(readFileSync(mf, 'utf8')))).map(p => `models: ${p.file} ${p.problem}`));
  const vp = join(root, 'models', MODEL, 'vocab.json'), lp = join(root, 'data/lexicon.json');
  if (existsSync(vp) && existsSync(lp)) {
    const vocab = JSON.parse(readFileSync(vp, 'utf8'));
    for (const p of validateAgainstVocab(JSON.parse(readFileSync(lp, 'utf8')), vocab)) problems.push(`lexicon: "${p.word}" ${p.ipa} has symbols the model cannot output: ${p.unknownSymbols.join(' ')}`);
  } else problems.push('cannot validate lexicon against model vocab (vocab.json or lexicon.json missing)');
  return problems;
}
if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  const p = await checkSetup(join(dirname(fileURLToPath(import.meta.url)), '..'), { modelOnly: process.argv.includes('--model-only') });
  console.log(p.length ? 'NOT READY:\n- ' + p.join('\n- ') : 'setup OK'); process.exit(p.length ? 1 : 0);
}
