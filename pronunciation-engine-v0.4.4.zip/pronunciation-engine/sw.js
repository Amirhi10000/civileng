// sw.js — offline cache (UNTESTED in a real browser). Registered from web/index.html; scope = project root.
// Precaches the model files listed in models/manifest.json, then caches every same-origin GET at runtime.
const CACHE = 'pe-v1';
self.addEventListener('install', e => e.waitUntil((async () => {
  const c = await caches.open(CACHE);
  await c.addAll(['./web/index.html', './src/engine.js', './src/worker.js', './src/core.js', './src/audio.js', './src/feedback-fa.js', './src/progress.js', './data/lexicon.json', './data/thresholds.json']);
  try {
    const m = await (await fetch('./models/manifest.json')).json();
    await c.addAll(m.files.map(f => `./models/${m.model}/${f.file}`));
  } catch { /* models not deployed: app will report it */ }
  self.skipWaiting();
})()));
self.addEventListener('activate', e => e.waitUntil(clients.claim()));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then(hit => hit ?? fetch(e.request).then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); return res; })));
});
