// Synthetic model output: each id → 2 peak frames + 1 blank; 'gap:N' → N blank frames.
export const vocab = { '<pad>': 0, ɪ: 1, n: 2, s: 3, p: 4, ɛ: 5, k: 6, t: 7, z: 8, i: 9 };
export const V = 10;
export function fake(items, { silence = false } = {}) {
  const frames = [];
  for (const it of items) {
    if (typeof it === 'string') for (let i = 0; i < Number(it.split(':')[1]); i++) frames.push(0);
    else frames.push(it, it, 0);
  }
  const T = silence ? 12 : frames.length + 2;
  const logits = new Float32Array(T * V).fill(-4);
  for (let t = 0; t < T; t++) logits[t * V + (silence ? 0 : (frames[t - 1] ?? 0))] = 6;
  return { logits, T, V };
}
