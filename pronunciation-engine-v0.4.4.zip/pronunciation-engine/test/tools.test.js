import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { extractWords, expandVariants, cleanIPA, validateAgainstVocab } from '../tools/build-lexicon.mjs';
import { calibrate, evaluate } from '../tools/calibrate.mjs';

const bank = JSON.parse(readFileSync(new URL('./fixtures/bank.json', import.meta.url), 'utf8'));

test('extractWords takes correct answers only, skips distractors and long phrases', () => {
  const w = extractWords(bank);
  for (const x of ['deterioration', 'account', 'withstand']) assert.ok(w.includes(x), x);
  assert.ok(!w.includes('elongation') && !w.includes('amount')); // wrong options are not targets
  assert.ok(!w.includes('ignored'));               // long paraphrase answer is not a target
  assert.deepEqual(w, [...w].sort());
  assert.equal(new Set(w).size, w.length);
  assert.deepEqual(extractWords({ questions: [{ subject: 'vocabulary', targetWord: 'Ductility', options: [], correctOptionId: 'A' }] }), ['ductility']);
});
test('expandVariants adds clear-t for flap, leaves others alone', () => {
  assert.deepEqual(expandVariants('static', 'stˈæɾɪk'), ['stˈæɾɪk', 'stˈætɪk']);
  assert.deepEqual(expandVariants('ladder', 'lˈæɾɚ'), ['lˈæɾɚ', 'lˈædɚ']);
  assert.equal(expandVariants('load', 'lˈoʊd'), 'lˈoʊd');
});
test('cleanIPA normalises espeak output', () => assert.equal(cleanIPA(' ɪnspˈɛkt\n'), 'ɪnspˈɛkt'));
test('validateAgainstVocab flags unknown symbols', () => {
  const p = validateAgainstVocab({ a: 'ɪn', b: 'ɪx' }, { ɪ: 1, n: 2 });
  assert.deepEqual(p, [{ word: 'b', ipa: 'ɪx', unknownSymbols: ['x'] }]);
});
test('calibrate separates clean synthetic classes', () => {
  const ok = (p) => ({ label: 'correct', phonemes: [p, 0.9, 0.85].map(prob => ({ prob, op: 'match' })) });
  const rows = [0.95, 0.9, 0.85, 0.8, 0.9].map(ok);
  rows.push(...[0.1, 0.2, 0.15, 0.05].map(p => ({ label: 'incorrect', phonemes: [{ prob: p, op: 'sub' }, { prob: 0.9, op: 'match' }, { prob: 0.9, op: 'match' }] })));
  const b = calibrate(rows);
  assert.equal(b.fa + b.fr, 0);
  assert.deepEqual(evaluate(rows, b.cfg).far, 0);
});
test('calibrate refuses one-class data', () => {
  assert.throws(() => calibrate([{ label: 'correct', phonemes: [{ prob: 1, op: 'match' }] }, { label: 'correct', phonemes: [{ prob: 1, op: 'match' }] }]), /both/);
});
test('build-lexicon CLI fails loudly without espeak-ng', () => {
  const r = spawnSync('node', ['tools/build-lexicon.mjs', '--bank', 'test/fixtures/bank.json', '--out', join(tmpdir(), 'lex-test.json')], { encoding: 'utf8', env: { ...process.env, PATH: '/nonexistent' } });
  assert.notEqual(r.status, 0);
});

import { cohenKappa, mergeLabels } from '../tools/merge-labels.mjs';
import { splitBySpeaker } from '../tools/calibrate.mjs';
import { goNoGo } from '../tools/go-nogo.mjs';
import { verifyManifest, sha256File } from '../tools/fetch-assets.mjs';
import { mkdtempSync, writeFileSync as wf, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';

test('cohenKappa: perfect = 1, chance-level ≈ 0', () => {
  assert.equal(cohenKappa(['a', 'b', 'a', 'b'], ['a', 'b', 'a', 'b']), 1);
  assert.ok(Math.abs(cohenKappa(['a', 'a', 'b', 'b'], ['a', 'b', 'a', 'b'])) < 1e-9);
});
test('mergeLabels keeps agreed labels, drops disagreement/unsure, strips audio, records intent mismatch', () => {
  const col = ['1', '2', '3', '4', '5'].map((id, i) => ({ id, speaker: 'S' + i, intent: 'correct', audioPcm16Base64: 'xx', phonemes: [] }));
  const mk = (rater, labels) => labels.map((label, i) => ({ id: String(i + 1), rater, label }));
  const r = mergeLabels(col, mk('R1', ['correct', 'incorrect', 'correct', 'unsure', 'correct']), mk('R2', ['correct', 'incorrect', 'incorrect', 'correct', 'correct']));
  assert.deepEqual(r.rows.map(x => x.id), ['1', '2', '5']);
  assert.deepEqual(r.dropped, { disagree: 1, unsure: 1, unrated: 0 });
  assert.equal(r.intentMismatch, 1);                  // speaker intended "correct", raters agreed "incorrect" (row 2)
  assert.ok(!('audioPcm16Base64' in r.rows[0]));
});
test('splitBySpeaker never shares a speaker between train and test', () => {
  const rows = Array.from({ length: 40 }, (_, i) => ({ speaker: 'S' + (i % 10), label: 'correct', phonemes: [] }));
  const { train, test } = splitBySpeaker(rows, 0.3);
  const a = new Set(train.map(r => r.speaker)), b = new Set(test.map(r => r.speaker));
  assert.ok(a.size && b.size && [...a].every(s => !b.has(s)));
});
import { clopperPearsonUpper, checkPreregistration } from '../tools/go-nogo.mjs';
import { criteriaHash, missingCriteria } from '../tools/preregister.mjs';
import { checkSetup } from '../tools/check-setup.mjs';

test('Clopper–Pearson upper bound: closed form at k=0, monotone, honest about small n', () => {
  assert.ok(Math.abs(clopperPearsonUpper(0, 30, 0.95) - (1 - Math.pow(0.05, 1 / 30))) < 1e-4);   // ≈ 9.5 %
  assert.ok(clopperPearsonUpper(0, 30, 0.95) > clopperPearsonUpper(0, 300, 0.95) * 5);          // 30 samples prove little
  assert.ok(clopperPearsonUpper(2, 30) > clopperPearsonUpper(1, 30));
  assert.equal(clopperPearsonUpper(5, 5), 1);
});
const crit = { minSpeakers: 8, minTestSpeakers: 2, minTestCorrect: 10, minTestIncorrect: 10, minKappa: 0.6, maxExcludedFraction: 0.2, confidence: 0.95, maxFalseRejectRate: 0.3, maxFalseAcceptRate: 0.3 };
const prereg = { criteriaSha256: criteriaHash(crit), registeredAt: '2026-11-01T00:00:00.000Z' };
const regFor = c => ({ criteriaSha256: criteriaHash(c), registeredAt: '2026-11-01T00:00:00.000Z' });
const mkRows = (n, at = '2026-11-02T00:00:00.000Z', hash = prereg.criteriaSha256) => Array.from({ length: n }, (_, i) => {
  const good = p => ({ prob: p, op: 'match' }), badp = { prob: 0.05, op: 'sub' };
  return { speaker: 'S' + (i % 10), recordedAt: at, preregSha256: hash, label: Math.floor(i / 10) % 2 ? 'incorrect' : 'correct', phonemes: Math.floor(i / 10) % 2 ? [badp, good(0.9)] : [good(0.9), good(0.9)] };  // every speaker records both classes
});
const cfg = { goodProb: 0.6, weakProb: 0.3, passScore: 70 };
const meta = { kappa: 0.8, excludedFraction: 0.05 };

test('go/no-go: needs pre-registered criteria, intact hash, and data recorded AFTER registration', () => {
  assert.deepEqual(missingCriteria({ ...crit, confidence: null }), ['confidence']);
  assert.throws(() => goNoGo(mkRows(200), { ...crit, confidence: null }, meta, cfg, prereg), /pre-registered/);
  assert.throws(() => goNoGo(mkRows(200), { ...crit, minKappa: 0.1 }, meta, cfg, prereg), /hash/);          // criteria edited afterwards
  assert.throws(() => goNoGo(mkRows(200, '2026-10-01T00:00:00.000Z'), crit, meta, cfg, prereg), /BEFORE/);   // data older than registration
  assert.deepEqual(checkPreregistration(crit, prereg, mkRows(4)), []);
});
test('go/no-go: verdict uses the UPPER confidence bound on held-out speakers', () => {
  const big = goNoGo(mkRows(600), crit, meta, cfg, prereg);
  assert.equal(big.verdict, 'GO'); assert.ok(big.heldOut.faUpper < 0.05);
  const c2 = { ...crit, minTestCorrect: 1, minTestIncorrect: 1, maxFalseAcceptRate: 0.05 }, p2 = regFor(c2);
  const tiny = goNoGo(mkRows(40, undefined, p2.criteriaSha256), c2, meta, cfg, p2);
  assert.equal(tiny.verdict, 'INCONCLUSIVE');                // zero observed errors, but too few samples to claim < 5 % — "not enough information", not "bad"
  assert.equal(tiny.heldOut.fa, 0); assert.ok(tiny.failedChecks.includes('falseAcceptUpper'));
  assert.equal(goNoGo(mkRows(600), crit, { kappa: 0.4, excludedFraction: 0.05 }, cfg, prereg).verdict, 'INCONCLUSIVE');   // unreliable labels never justify GO or NO-GO
  assert.equal(goNoGo(mkRows(600), crit, { kappa: 0.8, excludedFraction: 0.5 }, cfg, prereg).verdict, 'INCONCLUSIVE');
});
test('merge-labels reports excluded fraction', () => {
  const col = ['1', '2', '3', '4'].map((id, i) => ({ id, speaker: 'S' + i, phonemes: [] }));
  const mk = (rater, l) => l.map((label, i) => ({ id: String(i + 1), rater, label }));
  const r = mergeLabels(col, mk('R1', ['correct', 'correct', 'incorrect', 'unsure']), mk('R2', ['correct', 'incorrect', 'incorrect', 'correct']));
  assert.equal(r.excludedFraction, 0.5);
});
test('check-setup flags an empty bundle', async () => {
  const p = await checkSetup(mkdtempSync(join(tmpdir(), 'setup-')));
  assert.ok(p.some(x => /transformers/.test(x)) && p.some(x => /manifest/.test(x)));
});
test('asset manifest verification detects missing / corrupted files', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'assets-')), content = 'hello model';
  wf(join(dir, 'a.bin'), content);
  const manifest = { files: [{ file: 'a.bin', bytes: content.length, sha256: createHash('sha256').update(content).digest('hex') }, { file: 'b.bin', bytes: 1, sha256: 'x' }] };
  assert.deepEqual(await verifyManifest(dir, manifest), [{ file: 'b.bin', problem: 'missing' }]);
  wf(join(dir, 'a.bin'), 'hellO model');
  assert.equal((await verifyManifest(dir, manifest))[0].problem, 'sha256 mismatch');
});

import { speakerTUpper, tQuantile, robustUpper, anchorWarnings, clusterBootstrapUpper } from '../tools/go-nogo.mjs';
import { invalidCriteria, anchorOf } from '../tools/preregister.mjs';

test('criteria ranges are validated (confidence 95 instead of 0.95, negative counts, test > total speakers)', () => {
  assert.deepEqual(invalidCriteria(crit), []);
  assert.match(invalidCriteria({ ...crit, confidence: 95 })[0], /confidence/);
  assert.match(invalidCriteria({ ...crit, maxFalseAcceptRate: 5 })[0], /maxFalseAcceptRate/);
  assert.match(invalidCriteria({ ...crit, minSpeakers: 0 })[0], /minSpeakers/);
  assert.match(invalidCriteria({ ...crit, minTestSpeakers: 20 })[0], /cannot exceed/);
  assert.throws(() => goNoGo(mkRows(200), { ...crit, confidence: 95 }, meta, cfg, regFor({ ...crit, confidence: 95 })), /invalid criteria/);
});
test('t quantile is exact (table values), including tiny degrees of freedom', () => {
  for (const [q, df, ref] of [[0.95, 1, 6.3138], [0.95, 2, 2.9200], [0.95, 5, 2.0150], [0.95, 30, 1.6973], [0.99, 3, 4.5407]])
    assert.ok(Math.abs(tQuantile(q, df) - ref) < 1e-3, `q=${q} df=${df}`);
  assert.ok(Math.abs(tQuantile(0.05, 5) + 2.0150) < 1e-3);
});
test('clustered errors: speaker-aware bounds exceed the naive bound; zero errors stay low', () => {
  const m = new Map([['A', { k: 10, n: 10 }], ['B', { k: 0, n: 10 }], ['C', { k: 0, n: 10 }]]);     // one speaker fails everything
  const naive = clopperPearsonUpper(10, 30, 0.95);
  assert.ok(clusterBootstrapUpper(m, 0.95) > naive);
  assert.ok(robustUpper(m, 0.95) > naive);
  const none = new Map([...'ABCDEFGHIJ'].map(s => [s, { k: 0, n: 3 }]));
  assert.ok(Math.abs(robustUpper(none, 0.95) - clopperPearsonUpper(0, 30, 0.95)) < 1e-9);
});
test('anchor: tampering and missing external anchor are reported', () => {
  const p = { criteriaSha256: 'a'.repeat(64), registeredAt: '2026-11-01T00:00:00.000Z', git: null }; p.anchor = anchorOf(p);
  assert.ok(anchorWarnings(p).some(w => /no external anchor/.test(w)));
  assert.ok(!anchorWarnings(p, { expectedAnchor: p.anchor }).some(w => /altered|differs/.test(w)));
  assert.ok(anchorWarnings(p, { expectedAnchor: 'deadbeef' }).some(w => /altered/.test(w)));
  assert.ok(anchorWarnings({ ...p, registeredAt: '2026-01-01T00:00:00.000Z' }, { expectedAnchor: p.anchor }).some(w => /own fields/.test(w)));
});

test('NO-GO only when failure is clear (lower bound above the limit) AND labels are trustworthy', () => {
  // engine cannot tell wrong from right: every "incorrect" sample looks perfect → false-accept ≈ 100 %
  const rows = mkRows(600).map(r => (r.label === 'incorrect' ? { ...r, phonemes: [{ prob: 0.9, op: 'match' }, { prob: 0.9, op: 'match' }] } : r));
  const r = goNoGo(rows, crit, meta, cfg, prereg);
  assert.equal(r.verdict, 'NO-GO'); assert.ok(r.heldOut.faLower > crit.maxFalseAcceptRate);
  assert.equal(goNoGo(rows, crit, { kappa: 0.3, excludedFraction: 0.05 }, cfg, prereg).verdict, 'INCONCLUSIVE');
});
test('--require-anchor logic: missing/mismatching anchor blocks, missing git commit does not', async () => {
  const { blockingAnchorProblems } = await import('../tools/go-nogo.mjs');
  const p = { criteriaSha256: 'a'.repeat(64), registeredAt: '2026-11-01T00:00:00.000Z', git: null }; p.anchor = anchorOf(p);
  assert.ok(blockingAnchorProblems(anchorWarnings(p)).length > 0);                                   // no external anchor
  assert.ok(blockingAnchorProblems(anchorWarnings(p, { expectedAnchor: 'bad' })).length > 0);        // mismatch
  assert.deepEqual(blockingAnchorProblems(anchorWarnings(p, { expectedAnchor: p.anchor })), []);     // only "no git commit" left
});
test('leave-one-speaker-out: never trains on the held-out speaker, pools per-speaker counts', async () => {
  const { leaveOneSpeakerOut } = await import('../tools/calibrate.mjs');
  const rows = mkRows(240);                                                  // 10 speakers, both classes each
  const ok = leaveOneSpeakerOut(rows);
  assert.equal(ok.speakers, 10); assert.equal(ok.fr.size, 10); assert.equal(ok.totals.fr.k + ok.totals.fa.k, 0);
  // one speaker whose labels are inverted: errors must land on THAT speaker only (no leakage into its own training)
  const bad = rows.map(r => (r.speaker === 'S3' ? { ...r, label: r.label === 'correct' ? 'incorrect' : 'correct' } : r));
  const l = leaveOneSpeakerOut(bad);
  assert.ok(l.fr.get('S3').k + l.fa.get('S3').k > 0);
  for (const sp of [...'012456789'].map(x => 'S' + x)) assert.equal((l.fr.get(sp)?.k ?? 0) + (l.fa.get(sp)?.k ?? 0), 0, sp);
});
test('loso mode gives a verdict from ~12 speakers where a 30 % split would have too few', () => {
  const c = { ...crit, minSpeakers: 10, minTestSpeakers: 10, minTestCorrect: 40, minTestIncorrect: 40, confidence: 0.9, maxFalseRejectRate: 0.35, maxFalseAcceptRate: 0.35 }, pr = regFor(c);
  const rows = mkRows(480, undefined, pr.criteriaSha256);
  assert.equal(goNoGo(rows, c, meta, cfg, pr, { mode: 'loso' }).verdict, 'GO');
  assert.equal(goNoGo(rows, c, meta, cfg, pr, { mode: 'split' }).verdict, 'INCONCLUSIVE');   // only ~3 test speakers
});

test('regression: a tiny pilot with a clearly bad engine is INCONCLUSIVE, not NO-GO (insufficient data)', () => {
  const c = { ...crit, minSpeakers: 10, minTestSpeakers: 8, minTestCorrect: 40, minTestIncorrect: 40 }, pr = regFor(c);
  const rows = mkRows(30, undefined, pr.criteriaSha256).map(r => (r.label === 'incorrect' ? { ...r, phonemes: [{ prob: 0.9, op: 'match' }, { prob: 0.9, op: 'match' }] } : r));
  const r = goNoGo(rows, c, meta, cfg, pr);
  assert.equal(r.verdict, 'INCONCLUSIVE'); assert.ok(r.failedChecks.includes('testSpeakers'));
});

test('check-setup --model-only ignores vendor/ but still demands the model manifest', async () => {
  const p = await checkSetup(mkdtempSync(join(tmpdir(), 'setup2-')), { modelOnly: true });
  assert.ok(!p.some(x => /vendor|wasm|transformers/.test(x)));
  assert.ok(p.some(x => /manifest/.test(x)));
});
