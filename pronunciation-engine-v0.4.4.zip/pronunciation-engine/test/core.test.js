import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreWord, scoreUtterance, tokenizeIPA, decide, forcedAlign, logSoftmax, editAlign } from '../src/core.js';
import { vocab, fake, V } from './helpers.js';

const ipa = 'ɪnspˈɛkt', target = [1, 2, 3, 4, 5, 6, 7];

test('perfect pronunciation passes', () => {
  const r = scoreWord(fake(target), ipa, vocab);
  assert.ok(r.ok && r.correct && r.score >= 90);
  assert.equal(r.phonemeErrorRate, 0);
  assert.ok(r.phonemes.every(p => p.status === 'good'));
});
test('substitution s→z is located and named', () => {
  const r = scoreWord(fake([1, 2, 8, 4, 5, 6, 7]), ipa, vocab);
  assert.equal(r.correct, false);
  assert.deepEqual([r.phonemes[2].status, r.phonemes[2].saidInstead], ['wrong', 'z']);
  assert.ok(r.phonemes.filter(p => p.status === 'wrong').length === 1);
});
test('deleted phoneme is reported as missing', () => {
  const r = scoreWord(fake([1, 2, 4, 5, 6, 7]), ipa, vocab);
  assert.equal(r.correct, false);
  assert.equal(r.phonemes.filter(p => p.status === 'missing').length, 1);
});
test('inserted vowel is reported in extraSounds', () => {
  const r = scoreWord(fake([5, 1, 2, 3, 4, 5, 6, 7]), ipa, vocab);
  assert.deepEqual(r.extraSounds, ['ɛ']);
});
test('silence and too-short audio give explicit reasons', () => {
  assert.equal(scoreWord(fake(target, { silence: true }), ipa, vocab).reason, 'no_speech');
  const short = { logits: Float32Array.from({ length: 2 * V }, (_, i) => (i % V === 3 ? 6 : -4)), T: 2, V };
  assert.equal(scoreWord(short, ipa, vocab).reason, 'too_short');
});
test('unknown target symbols are reported, empty target rejected', () => {
  assert.deepEqual(tokenizeIPA('ɪxn', vocab).dropped, ['x']);
  assert.equal(scoreWord(fake(target), 'xyq', vocab).reason, 'empty_target');
});
test('decide() is the single rule: thresholds change the verdict', () => {
  const ph = [{ prob: 0.9, op: 'match' }, { prob: 0.45, op: 'match' }];
  assert.equal(decide(ph, { goodProb: 0.6, weakProb: 0.3, passScore: 50 }).correct, true);
  assert.equal(decide(ph, { goodProb: 0.6, weakProb: 0.3, passScore: 90 }).correct, false);
  assert.equal(decide(ph, { goodProb: 0.6, weakProb: 0.5, passScore: 10 }).correct, false); // 0.45 < weakProb → wrong
});
test('utterance: per-word verdicts, fluency and long pause', () => {
  const r = scoreUtterance(fake([1, 2, 3, 'gap:40', 7, 1, 2]), [{ word: 'ins', ipa: 'ɪns' }, { word: 'tin', ipa: 'tɪn' }], vocab);
  assert.ok(r.ok && r.correct);
  assert.equal(r.words.length, 2);
  assert.equal(r.fluency.longPauses, 1);
  assert.ok(r.fluency.gapsSeconds[0] > 0.6);
  const bad = scoreUtterance(fake([1, 2, 3, 7, 8, 2]), [{ word: 'ins', ipa: 'ɪns' }, { word: 'tin', ipa: 'tɪn' }], vocab);
  assert.deepEqual(bad.words.map(w => w.correct), [true, false]);
});
test('forcedAlign handles repeated phonemes (needs a blank between)', () => {
  const lp = logSoftmax(fake([1, 1]).logits, 8, V);
  const f = forcedAlign(lp, 8, V, [1, 1], 0);
  assert.equal(f.length, 2);
  assert.ok(f[0].at(-1) < f[1][0]);
});
test('logSoftmax rows sum to 1', () => {
  const lp = logSoftmax(fake(target).logits, 5, V);
  for (let t = 0; t < 5; t++) assert.ok(Math.abs([...lp.slice(t * V, t * V + V)].reduce((a, v) => a + Math.exp(v), 0) - 1) < 1e-5);
});
test('editAlign', () => {
  assert.deepEqual(editAlign([1, 2, 3], [1, 3]).ops.map(o => o.op), ['match', 'del', 'match']);
  assert.equal(editAlign([1, 2], [1, 2]).distance, 0);
});

test('regression: repeated phonemes in too-short audio give too_short, never a bogus score', () => {
  const T = 2, logits = new Float32Array(T * V).fill(-4); logits[3] = 6; logits[V + 3] = 6;
  assert.equal(scoreWord({ logits, T, V }, 'ss', vocab).reason, 'too_short');
});
test('accepted variants: either pronunciation passes, best variant is reported', () => {
  // variants: "ɪnst" (target) vs "ɪnsk" — speaker says ɪ n s k
  const out = fake([1, 2, 3, 6]);
  const single = scoreWord(out, 'ɪnst', vocab);
  assert.equal(single.correct, false);
  const multi = scoreWord(out, ['ɪnst', 'ɪnsk'], vocab);
  assert.ok(multi.correct); assert.equal(multi.variant, 1);
  assert.equal(scoreWord(fake([1, 2, 3, 7]), ['ɪnst', 'ɪnsk'], vocab).variant, 0);
});
