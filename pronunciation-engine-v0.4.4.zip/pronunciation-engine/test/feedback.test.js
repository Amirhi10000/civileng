import test from 'node:test';
import assert from 'node:assert/strict';
import { explainPhoneme, explainWord, coachingNotice, REVIEW_STATUS } from '../src/feedback-fa.js';

test('known confusion gets a specific Persian rule', () => {
  assert.match(explainPhoneme({ phoneme: 'θ', status: 'wrong', saidInstead: 's' }), /بین دندون/);
  assert.match(explainPhoneme({ phoneme: 'w', status: 'wrong', saidInstead: 'v' }), /لب‌ها رو گرد/);
});
test('missing and unknown confusions fall back gracefully', () => {
  assert.match(explainPhoneme({ phoneme: 'h', status: 'missing' }), /ته گلو/);
  assert.match(explainPhoneme({ phoneme: 'k', status: 'wrong', saidInstead: 'g' }), /«k».*«g»/);
  assert.equal(explainPhoneme({ phoneme: 'k', status: 'good' }), null);
});
test('epenthesis before s+consonant is detected first', () => {
  const m = explainWord({ ok: true, correct: false, extraSounds: ['ɛ'], phonemes: [{ phoneme: 's', status: 'good', prob: 0.9 }, { phoneme: 't', status: 'weak', prob: 0.4 }] });
  assert.match(m[0], /واکه‌ی اضافه/);
});
test('worst phonemes first, max 3, praise when correct', () => {
  const ph = ['a', 'b', 'c', 'd'].map((x, i) => ({ phoneme: x, status: 'wrong', prob: 0.1 * (i + 1), saidInstead: 'z' }));
  const m = explainWord({ ok: true, correct: false, extraSounds: [], phonemes: ph });
  assert.equal(m.length, 3); assert.match(m[0], /«a»/);
  assert.match(explainWord({ ok: true, correct: true })[0], /آفرین/);
});

test('w>v advice no longer equates Persian «و» with /w/', () => {
  const m = explainPhoneme({ phoneme: 'w', status: 'wrong', saidInstead: 'v' });
  assert.match(m, /«v»/); assert.doesNotMatch(m, /وای/);
});

test('unreviewed coaching carries a learner-visible notice; reviewed does not', () => {
  assert.equal(REVIEW_STATUS, 'draft-unreviewed');
  assert.match(coachingNotice(), /بازبینی نشده/);
  assert.equal(coachingNotice('reviewed'), null);
});
