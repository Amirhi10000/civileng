import test from 'node:test';
import assert from 'node:assert/strict';
import { ProgressTracker, MemoryStorage } from '../src/progress.js';

const vocab = { '<pad>': 0, θ: 1, ɪ: 2, ŋ: 3, k: 4, s: 5, t: 6 };
const lex = { think: 'θɪŋk', sit: 'sɪt', tin: 'tɪn' };
const res = (correct, ph) => ({ ok: true, correct, phonemes: ph });
const bad = { phoneme: 'θ', status: 'wrong', prob: 0.1, saidInstead: 's' };
const good = p => ({ phoneme: p, status: 'good', prob: 0.9, saidInstead: null });

test('weak phonemes and confusions are tracked', async () => {
  let now = 0; const tr = new ProgressTracker(new MemoryStorage(), { now: () => now });
  for (let i = 0; i < 4; i++) await tr.record('u', 'think', res(false, [bad, good('ɪ'), good('ŋ'), good('k')]));
  const w = await tr.weakPhonemes('u');
  assert.equal(w[0].phoneme, 'θ'); assert.ok(w[0].errorRate > 0.9);
  assert.deepEqual(await tr.topConfusions('u'), [{ pair: 'θ>s', count: 4 }]);
});
test('minimum attempts guard hides noise', async () => {
  const tr = new ProgressTracker(new MemoryStorage());
  await tr.record('u', 'think', res(false, [bad]));
  assert.deepEqual(await tr.weakPhonemes('u'), []);
});
test('next words favour weak phonemes; passed words wait for their interval', async () => {
  let now = 1000; const tr = new ProgressTracker(new MemoryStorage(), { now: () => now });
  for (let i = 0; i < 5; i++) await tr.record('u', 'think', res(false, [bad, good('ɪ'), good('ŋ'), good('k')]));
  await tr.record('u', 'sit', res(true, [good('s'), good('ɪ'), good('t')]));
  const lex2 = { ...lex, thin: 'θɪn' };
  let q = await tr.nextWords('u', lex2, vocab, 3);
  assert.equal(q[0].word, 'thin');                    // unseen word containing the weak phoneme ranks first
  assert.ok(!q.some(x => x.word === 'think'));        // just failed → not repeated today
  assert.ok(!q.some(x => x.word === 'sit'));          // 1st success → due in 3 days
  now += 2 * 86400000;
  assert.ok(!(await tr.nextWords('u', lex, vocab, 3)).some(x => x.word === 'sit'));
  now += 86400000 + 1;
  q = await tr.nextWords('u', lex, vocab, 3);
  assert.ok(q.some(x => x.word === 'sit'));
});
test('users are isolated and storage is not aliased', async () => {
  const tr = new ProgressTracker(new MemoryStorage());
  await tr.record('a', 'think', res(false, [bad]));
  assert.deepEqual(await tr.topConfusions('b'), []);
});

test('a failed word is NOT immediately due again (box 0 = tomorrow); intervals are configurable', async () => {
  let now = 5000; const tr = new ProgressTracker(new MemoryStorage(), { now: () => now });
  await tr.record('u', 'sit', res(false, [good('s')]));
  assert.ok(!(await tr.nextWords('u', lex, vocab, 5)).some(x => x.word === 'sit'));
  now += 86400000 + 1;
  assert.ok((await tr.nextWords('u', lex, vocab, 5)).some(x => x.word === 'sit'));
  const t2 = new ProgressTracker(new MemoryStorage(), { now: () => 0, intervalsDays: [2, 5], retryDays: 1 });
  await t2.record('u', 'sit', res(false, [good('s')]));
  assert.equal((await t2.s.get('user:u')).words.sit.due, 86400000);
  await t2.record('u', 'sit', res(true, [good('s')]));
  assert.equal((await t2.s.get('user:u')).words.sit.due, 2 * 86400000);
});
test('lexicon entries with variants are supported', async () => {
  const tr = new ProgressTracker(new MemoryStorage());
  const q = await tr.nextWords('u', { sit: ['sɪt', 'sɪk'] }, vocab, 1);
  assert.equal(q[0].word, 'sit');
});

test('system schedule: fail→1d; successes→3d,7d,14d; 4th success = mastered and leaves the queue; a later failure re-enters', async () => {
  let now = 0; const tr = new ProgressTracker(new MemoryStorage(), { now: () => now }), D = 86400000, due = async () => (await tr.s.get('user:u')).words.sit.due;
  await tr.record('u', 'sit', res(false, [good('s')])); assert.equal(await due(), 1 * D);
  for (const days of [3, 7, 14]) { now = 100 * D; await tr.record('u', 'sit', res(true, [good('s')])); assert.equal(await due(), 100 * D + days * D); }
  await tr.record('u', 'sit', res(true, [good('s')]));
  assert.deepEqual(await tr.masteredWords('u'), ['sit']); assert.equal(await due(), null);
  now = 10000 * D;
  assert.ok(!(await tr.nextWords('u', lex, vocab, 5)).some(x => x.word === 'sit'));
  await tr.record('u', 'sit', res(false, [good('s')]));
  assert.deepEqual(await tr.masteredWords('u'), []);
});
