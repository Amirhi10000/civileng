import test from 'node:test';
import assert from 'node:assert/strict';
import { trimSilence, checkQuality, SR } from '../src/audio.js';

const burst = (sec, amp = 0.3) => Float32Array.from({ length: Math.round(sec * SR) }, (_, i) => amp * Math.sin(2 * Math.PI * 220 * i / SR));
const cat = (...a) => { const o = new Float32Array(a.reduce((s, x) => s + x.length, 0)); let k = 0; for (const x of a) { o.set(x, k); k += x.length; } return o; };
const sil = sec => new Float32Array(Math.round(sec * SR)).fill(0.0005);

test('trimSilence keeps speech plus padding only', () => {
  const t = trimSilence(cat(sil(1), burst(0.5), sil(1)));
  assert.ok(Math.abs(t.length / SR - 0.8) < 0.05, `got ${t.length / SR}`);
});
test('trimSilence of pure silence is empty', () => assert.equal(trimSilence(sil(1)).length, 0));
test('quality gate: ok / short / long / quiet / clipping', () => {
  assert.equal(checkQuality(burst(1)).ok, true);
  assert.equal(checkQuality(burst(0.1)).reason, 'too_short');
  assert.equal(checkQuality(burst(9)).reason, 'too_long');
  assert.equal(checkQuality(burst(1, 0.005)).reason, 'too_quiet');
  assert.equal(checkQuality(new Float32Array(SR).fill(1)).reason, 'clipping');
});
