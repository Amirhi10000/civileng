// src/engine.js — browser glue (main thread): recording, quality gate, worker RPC, scoring, coaching, TTS.
// No network access at runtime: model + runtime are served from this origin (see README "Offline packaging").
import { scoreWord } from './core.js';
import { checkQuality, trimSilence } from './audio.js';
import { explainWord, coachingNotice } from './feedback-fa.js';

export class PronunciationEngine {
  constructor({ thresholds = {} } = {}) { this.thresholds = thresholds; this.pending = new Map(); this.seq = 0; }

  init(onProgress) {
    this.worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
    return new Promise((resolve, reject) => {
      this.worker.onerror = e => reject(new Error('worker failed to load (are vendor/ and models/ in place?): ' + e.message));
      this.worker.onmessage = ({ data }) => {
        if (data.type === 'progress') onProgress?.(data.p);
        else if (data.type === 'ready') { this.vocab = data.vocab; this.worker.onmessage = e => this._onMsg(e.data); resolve(); }
        else if (data.type === 'error') reject(new Error(data.message));
      };
      this.worker.postMessage({ type: 'init' });
    });
  }
  _onMsg(d) {
    const p = this.pending.get(d.id); if (!p) return;
    this.pending.delete(d.id);
    d.type === 'error' ? p.reject(new Error(d.message)) : p.resolve(d);
  }
  _infer(x) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => { this.pending.set(id, { resolve, reject }); this.worker.postMessage({ type: 'infer', id, x }, [x.buffer]); });
  }

  // ipa: string or array of accepted variants. audio: Float32Array mono 16 kHz.
  async assess(ipa, audio) {
    const q = checkQuality(audio);
    if (!q.ok) return { ok: false, retry: true, reason: q.reason, quality: q };
    const a = trimSilence(audio);
    if (a.length < 4000) return { ok: false, retry: true, reason: 'no_speech', quality: q };
    const mean = a.reduce((s, v) => s + v, 0) / a.length;
    const sd = Math.sqrt(a.reduce((s, v) => s + (v - mean) ** 2, 0) / a.length + 1e-7);
    const { logits, T, V } = await this._infer(Float32Array.from(a, v => (v - mean) / sd));
    const r = scoreWord({ logits, T, V }, ipa, this.vocab, this.thresholds);
    if (!r.ok) return { ...r, retry: r.reason !== 'empty_target', quality: q };
    return { ...r, quality: q, coaching: explainWord(r), coachingNotice: coachingNotice() };
  }

  speak(word, lang = 'en-US', rate = 0.85) { // on-device TTS where the OS provides it
    if (!('speechSynthesis' in window)) return false;
    const u = new SpeechSynthesisUtterance(word); u.lang = lang; u.rate = rate;
    speechSynthesis.cancel(); speechSynthesis.speak(u); return true;
  }
}

// Browser DSP can alter phonemes, so the default is RAW capture. Whatever is used must be recorded with the data.
export const RAW_CAPTURE = { echoCancellation: false, noiseSuppression: false, autoGainControl: false };
export async function startRecording(capture = RAW_CAPTURE) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, ...capture } });
  const rec = new MediaRecorder(stream), chunks = [];
  rec.ondataavailable = e => chunks.push(e.data);
  const done = new Promise(res => rec.onstop = async () => {
    stream.getTracks().forEach(t => t.stop());
    const ctx = new AudioContext({ sampleRate: 16000 });
    const decoded = await ctx.decodeAudioData(await new Blob(chunks).arrayBuffer());
    ctx.close();
    res(decoded.getChannelData(0));
  });
  rec.start();
  return { stop: () => { rec.stop(); return done; } };
}
