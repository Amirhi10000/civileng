// src/progress.js — per-learner weakness model + Leitner spaced repetition.
// Storage is injected (async get/set) so the same code runs in browser, Node, or native bridges.
import { tokenizeIPA } from './core.js';

// Failure → box 0 → tomorrow (retryDays). 1st/2nd/3rd consecutive success → 3/7/14 days. 4th → mastered (leaves the active queue).
const DAY = 86400000, DEFAULT_INTERVALS = [3, 7, 14]; // days after the 1st/2nd/3rd consecutive success; retryDays after a failure
const BAD = new Set(['wrong', 'missing']);

export class MemoryStorage {
  constructor() { this.m = new Map(); }
  async get(k) { return this.m.has(k) ? structuredClone(this.m.get(k)) : null; }
  async set(k, v) { this.m.set(k, structuredClone(v)); }
}
export class LocalStorageAdapter {
  constructor(prefix = 'pe:') { this.p = prefix; }
  async get(k) { try { return JSON.parse(localStorage.getItem(this.p + k)); } catch { return null; } }
  async set(k, v) { localStorage.setItem(this.p + k, JSON.stringify(v)); }
}

export class ProgressTracker {
  constructor(storage, { alpha = 0.2, now = () => Date.now(), intervalsDays = DEFAULT_INTERVALS, retryDays = 1 } = {}) { this.s = storage; this.alpha = alpha; this.now = now; this.iv = intervalsDays; this.retry = retryDays; }
  async _load(u) { return (await this.s.get('user:' + u)) ?? { v: 1, phonemes: {}, pairs: {}, words: {} }; }

  // result: flat output of scoreWord (must be ok)
  async record(user, word, result) {
    if (!result.ok) return;
    const st = await this._load(user);
    for (const p of result.phonemes) {
      const e = BAD.has(p.status) ? 1 : p.status === 'weak' ? 0.5 : 0;
      const cur = st.phonemes[p.phoneme] ?? { attempts: 0, ema: e };
      cur.ema = cur.attempts === 0 ? e : cur.ema * (1 - this.alpha) + e * this.alpha;
      cur.attempts++;
      st.phonemes[p.phoneme] = cur;
      if (BAD.has(p.status) && p.saidInstead) { const k = `${p.phoneme}>${p.saidInstead}`; st.pairs[k] = (st.pairs[k] ?? 0) + 1; }
    }
    const w = st.words[word] ?? { box: 0, attempts: 0, passes: 0 };
    w.attempts++;
    if (result.correct) { w.passes++; w.box = Math.min(w.box + 1, this.iv.length + 1); } else { w.box = 0; w.mastered = false; }
    w.mastered = w.box > this.iv.length;                 // 4th consecutive success ⇒ mastered, no next due date
    w.due = w.mastered ? null : this.now() + (w.box === 0 ? this.retry : this.iv[w.box - 1]) * DAY;
    st.words[word] = w;
    await this.s.set('user:' + user, st);
  }

  async weakPhonemes(user, n = 5, minAttempts = 3) {
    const st = await this._load(user);
    return Object.entries(st.phonemes).filter(([, v]) => v.attempts >= minAttempts)
      .map(([phoneme, v]) => ({ phoneme, errorRate: +v.ema.toFixed(3), attempts: v.attempts }))
      .sort((a, b) => b.errorRate - a.errorRate).slice(0, n);
  }
  async masteredWords(user) { const st = await this._load(user); return Object.entries(st.words).filter(([, w]) => w.mastered).map(([w]) => w); }
  async topConfusions(user, n = 5) {
    const st = await this._load(user);
    return Object.entries(st.pairs).sort((a, b) => b[1] - a[1]).slice(0, n).map(([pair, count]) => ({ pair, count }));
  }

  // Practice queue: due words first, then words rich in the learner's weak phonemes, then unseen words.
  async nextWords(user, lexicon, vocab, n = 5) {
    const st = await this._load(user), t = this.now();
    const scored = Object.entries(lexicon).map(([word, ipa]) => {
      const syms = tokenizeIPA(Array.isArray(ipa) ? ipa[0] : ipa, vocab).symbols;
      const weak = syms.reduce((a, s) => { const p = st.phonemes[s]; return a + (p ? p.ema * Math.min(1, p.attempts / 5) : 0); }, 0) / (syms.length || 1);
      const w = st.words[word];
      if (w?.mastered) return { word, priority: -1, due: false };
      const priority = (w ? (w.due <= t ? 1 : 0) : 0.3) + 2 * weak;
      return { word, priority: +priority.toFixed(3), due: !w || w.due <= t };
    });
    return scored.filter(x => x.due).sort((a, b) => b.priority - a.priority || a.word.localeCompare(b.word)).slice(0, n);
  }
}
