// src/feedback-fa.js — Persian-language coaching for Persian-speaking learners of English.
// STATUS: draft — every message must be reviewed by a linguist / phonetics-trained teacher before release.
// Keys are "target>said" (IPA symbols as produced by the espeak phoneme model).

export const REVIEW_STATUS = 'draft-unreviewed';
// Shown to the learner next to every tip until a reviewer flips REVIEW_STATUS.
export function coachingNotice(status = REVIEW_STATUS) {
  return status === 'draft-unreviewed' ? '⚠️ این راهنمایی‌ها هنوز توسط متخصص بازبینی نشده‌اند؛ آن‌ها را قطعی ندان.' : null;
}
const RULES = {
  'θ>s': 'برای «th» نوک زبان رو کمی بین دندون‌ها بذار و هوا رو آروم بده بیرون. با «س» فرق داره: زبان نباید پشت دندون‌ها بمونه.',
  'θ>t': 'برای «th» نوک زبان رو بین دندون‌ها بذار و هوا رو بده بیرون. «ت» نیست؛ زبان نباید جلوی هوا رو کامل ببنده.',
  'θ>f': 'برای «th» لب پایین رو به دندون‌ها نزن (اون «ف» می‌شه). فقط نوک زبان بین دندون‌هاست.',
  'ð>z': 'برای «th» صدادار (مثل this) نوک زبان بین دندون‌هاست و تارهای صوتی می‌لرزن. «ز» نیست.',
  'ð>d': 'برای «th» صدادار زبان رو به دندون‌ها بچسبون ولی کامل نبند؛ هوا باید از لای زبان و دندون رد بشه. «د» نیست.',
  'w>v': 'توی فارسی «w» نداریم؛ «و»ی فارسی همون «v» با دندون روی لبه. برای «w» انگلیسی لب‌ها رو گرد کن (مثل شروع گفتن «اُ») و دندون‌ها به لب پایین نزنن، بعد سریع به واکه‌ی بعدی بلغز.',
  'v>w': 'برای «v» دندون‌های بالا رو آروم روی لب پایین بذار.',
  'v>f': 'برای «v» مثل «f» جای دندون و لب رو بگیر، ولی تارهای صوتی باید بلرزن.',
  'ɪ>i': 'صدای «ɪ» (مثل sit) کوتاه و شل‌تره. «ای» کشیده‌ی «ee» (مثل seat) نیست.',
  'i>ɪ': 'صدای «ee» (مثل seat) کشیده‌تر و بازتره. کوتاهش نکن.',
  'ʊ>u': 'صدای «ʊ» (مثل book) کوتاه و شل‌تره. «او»ی کشیده (مثل food) نیست.',
  'æ>ɛ': 'برای «æ» (مثل cat) دهان رو بازتر کن و فک رو بیشتر پایین بیار.',
  'æ>a': 'برای «æ» (مثل cat) زبان کمی بالاتر و جلوتر از «آ»ی فارسیه.',
  'ʌ>ɑ': 'برای «ʌ» (مثل cup) دهان نیمه‌بازه و صدا کوتاه‌ه. «آ»ی کشیده نیست.',
  'ɹ>r': 'برای «r» انگلیسی زبان به سقف دهان نمی‌خوره و نمی‌لرزه. نوک زبان رو کمی عقب بکش و بدون ضربه بگو.',
  'ŋ>n': 'برای «ng» ته زبان به سقف نرم دهان می‌چسبه. نوک زبان کار نمی‌کنه.',
  'dʒ>ʒ': 'برای «j» اول صدا یه «د» کوتاه داره و بعد «ژ»؛ هر دو باید باشن.',
  'tʃ>ʃ': 'برای «ch» اول یه «ت» کوتاه و بعد «ش». فقط «ش» کافی نیست.',
  'ʒ>ʃ': 'صدای «ʒ» (مثل vision) مثل «ژ» با لرزش تارهای صوتیه، نه «ش».',
};
const MISSING = {
  h: 'صدای «h» افتاد. هوا رو از ته گلو بده بیرون، مثل «ه»ی آخر نفس.',
  'ə': 'واکه‌ی کوتاه و ضعیف «ə» (شوا) افتاد. توی هجاهای بی‌تکیه، واکه رو کوتاه ولی حتماً بگو.',
  t: 'صدای «t» افتاد، مخصوصاً آخر کلمه. نوک زبان رو به سقف دهان بزن.',
  d: 'صدای «d» افتاد، مخصوصاً آخر کلمه. نوک زبان رو به سقف دهان بزن.',
  s: 'صدای «s» افتاد، مخصوصاً آخر کلمه. جمع‌ها و زمان‌ها رو کامل بگو.',
};
const TIPS = { θ: 'نوک زبان بین دندون‌ها', ð: 'نوک زبان بین دندون‌ها + لرزش تار صوتی', w: 'لب‌ها گرد', ɹ: 'زبان بدون لرزش', ŋ: 'ته زبان به سقف نرم' };
const VOWELS = new Set(['ɪ', 'ɛ', 'e', 'i', 'ə', 'æ', 'ɑ', 'ʌ', 'ʊ', 'u', 'o', 'ɔ', 'a', 'ɐ']);
const SC_NEXT = new Set(['t', 'p', 'k', 'm', 'n', 'l', 'w']);

export function explainPhoneme(p) {
  if (p.status === 'good') return null;
  if (p.status === 'missing') return MISSING[p.phoneme] ?? `صدای «${p.phoneme}» شنیده نشد. حواست باشه کامل بگیش.`;
  const rule = RULES[`${p.phoneme}>${p.saidInstead}`];
  if (rule) return rule;
  const tip = TIPS[p.phoneme] ? ` نکته: ${TIPS[p.phoneme]}.` : '';
  if (p.saidInstead) return `به‌جای «${p.phoneme}» صدای «${p.saidInstead}» شنیده شد.${tip}`;
  return `صدای «${p.phoneme}» واضح نبود.${tip}`;
}

// Epenthesis: Persian speakers often insert a vowel before s+consonant (e.g. "estructure").
function epenthesis(word) {
  const ph = word.phonemes;
  return ph.length > 1 && ph[0].phoneme === 's' && SC_NEXT.has(ph[1].phoneme) ? 'وسط شروع کلمه (s + صامت) یه واکه‌ی اضافه شنیده شد (مثل «اِ‌استراکچر»). مستقیم از «s» بپر روی صامت بعدی.' : null;
}

// result: output of scoreWord (flat) → ordered list of messages, worst first, max 3.
export function explainWord(result, { max = 3 } = {}) {
  if (!result.ok) return [];
  if (result.correct) return ['آفرین! تلفظ درست بود.'];
  const msgs = [];
  if (result.extraSounds.some(s => VOWELS.has(s))) { const m = epenthesis(result); if (m) msgs.push(m); }
  [...result.phonemes].filter(p => p.status !== 'good').sort((a, b) => a.prob - b.prob)
    .forEach(p => { const m = explainPhoneme(p); if (m && !msgs.includes(m)) msgs.push(m); });
  return msgs.slice(0, max);
}
