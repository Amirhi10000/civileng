// src/core.js — pure scoring logic. No model, no DOM, no dependencies.
// Input: CTC log-posteriors from a phoneme-recognition model + target IPA.
// Single source of truth for every verdict: decide().

export const FRAME_S = 0.02; // wav2vec2: 320 samples @16 kHz per frame
export const DEFAULTS = { goodProb: 0.6, weakProb: 0.3, passScore: 70 };
const BAD = new Set(['wrong', 'missing']);

export function logSoftmax(logits, T, V) {
  const out = new Float32Array(T * V);
  for (let t = 0; t < T; t++) {
    let max = -Infinity;
    for (let v = 0; v < V; v++) max = Math.max(max, logits[t * V + v]);
    let sum = 0;
    for (let v = 0; v < V; v++) sum += Math.exp(logits[t * V + v] - max);
    const lse = max + Math.log(sum);
    for (let v = 0; v < V; v++) out[t * V + v] = logits[t * V + v] - lse;
  }
  return out;
}

// IPA → token ids, longest match against model vocab (tʃ, aɪ …). Stress/syllable marks ignored.
export function tokenizeIPA(ipa, vocab) {
  const chars = Array.from(ipa.replace(/[ˈˌ.\s_]/g, ''));
  const ids = [], symbols = [], dropped = [];
  for (let i = 0; i < chars.length;) {
    let hit = null;
    for (let len = Math.min(3, chars.length - i); len >= 1; len--) {
      const s = chars.slice(i, i + len).join('');
      if (Object.hasOwn(vocab, s)) { hit = [s, len]; break; }
    }
    if (hit) { ids.push(vocab[hit[0]]); symbols.push(hit[0]); i += hit[1]; }
    else { dropped.push(chars[i]); i++; }
  }
  return { ids, symbols, dropped };
}

// Viterbi forced alignment (CTC topology). Returns frames[i] = frame indices of target token i, or null.
export function forcedAlign(lp, T, V, ids, blank) {
  const N = ids.length, S = 2 * N + 1;
  if (N === 0) return null;
  let need = N;                                   // identical neighbours need a blank frame between them
  for (let i = 1; i < N; i++) if (ids[i] === ids[i - 1]) need++;
  if (T < need) return null;
  const NEG = -1e30;
  const lab = s => (s % 2 === 0 ? blank : ids[(s - 1) >> 1]);
  let prev = new Float64Array(S).fill(NEG), cur = new Float64Array(S);
  const bp = new Int8Array(T * S);
  prev[0] = lp[blank]; prev[1] = lp[ids[0]];
  for (let t = 1; t < T; t++) {
    for (let s = 0; s < S; s++) {
      let best = prev[s], from = 0;
      if (s >= 1 && prev[s - 1] > best) { best = prev[s - 1]; from = 1; }
      if (s >= 3 && s % 2 === 1 && ids[(s - 1) >> 1] !== ids[(s - 3) >> 1] && prev[s - 2] > best) { best = prev[s - 2]; from = 2; }
      cur[s] = best + lp[t * V + lab(s)];
      bp[t * S + s] = from;
    }
    [prev, cur] = [cur, prev];
  }
  let s = prev[S - 1] >= prev[S - 2] ? S - 1 : S - 2;
  const frames = Array.from({ length: N }, () => []);
  for (let t = T - 1; t >= 0; t--) {
    if (s % 2 === 1) frames[(s - 1) >> 1].push(t);
    s -= bp[t * S + s];
  }
  if (frames.some(f => f.length === 0)) return null; // invalid path → never return partial alignments
  frames.forEach(f => f.reverse());
  return frames;
}

export function greedyDecode(lp, T, V, blank) {
  const out = []; let last = -1;
  for (let t = 0; t < T; t++) {
    let b = 0, bv = -Infinity;
    for (let v = 0; v < V; v++) if (lp[t * V + v] > bv) { bv = lp[t * V + v]; b = v; }
    if (b !== last && b !== blank) out.push(b);
    last = b;
  }
  return out;
}

export function editAlign(target, heard) {
  const n = target.length, m = heard.length;
  const d = Array.from({ length: n + 1 }, (_, i) => Array(m + 1).fill(0));
  for (let i = 0; i <= n; i++) d[i][0] = i;
  for (let j = 0; j <= m; j++) d[0][j] = j;
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++)
    d[i][j] = Math.min(d[i-1][j] + 1, d[i][j-1] + 1, d[i-1][j-1] + (target[i-1] === heard[j-1] ? 0 : 1));
  const ops = Array(n).fill(null), insertions = [];
  let i = n, j = m;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && d[i][j] === d[i-1][j-1] + (target[i-1] === heard[j-1] ? 0 : 1)) {
      ops[i-1] = target[i-1] === heard[j-1] ? { op: 'match' } : { op: 'sub', heard: heard[j-1] };
      i--; j--;
    } else if (i > 0 && d[i][j] === d[i-1][j] + 1) { ops[i-1] = { op: 'del' }; i--; }
    else { insertions.push(heard[j-1]); j--; }
  }
  return { ops, insertions: insertions.reverse(), distance: d[n][m] };
}

// ---- Decision rule (calibratable; used by scoreUtterance AND tools/calibrate.mjs) ----
export function phonemeStatus(p, cfg) {
  if (p.prob < cfg.goodProb) {
    if (p.op === 'del') return 'missing';
    if (p.op === 'sub') return 'wrong';
  }
  return p.prob >= cfg.goodProb ? 'good' : p.prob >= cfg.weakProb ? 'weak' : 'wrong';
}
export function decide(phonemes, cfg = {}) {
  const c = { ...DEFAULTS, ...cfg };
  const statuses = phonemes.map(p => phonemeStatus(p, c));
  const sum = phonemes.reduce((a, p, i) => a + (BAD.has(statuses[i]) ? 0 : p.prob), 0);
  const score = Math.round(100 * sum / phonemes.length);
  return { score, statuses, correct: score >= c.passScore && !statuses.some(s => BAD.has(s)) };
}

function analyse(lp, T, V, ids, blank) {
  const heard = greedyDecode(lp, T, V, blank);
  if (!heard.length) return { error: 'no_speech' };
  const frames = forcedAlign(lp, T, V, ids, blank);
  if (!frames) return { error: 'too_short' };
  const { ops, insertions, distance } = editAlign(ids, heard);
  const tokens = ids.map((id, i) => {
    let bestT = frames[i][0], bestP = -Infinity;
    for (const t of frames[i]) if (lp[t * V + id] > bestP) { bestP = lp[t * V + id]; bestT = t; }
    let comp = -1, cp = -Infinity; // strongest competing non-blank phoneme at the peak frame
    for (let v = 0; v < V; v++) if (v !== blank && v !== id && lp[bestT * V + v] > cp) { cp = lp[bestT * V + v]; comp = v; }
    return { id, prob: Math.exp(bestP), op: ops[i].op, heardId: ops[i].heard, compId: comp,
             first: frames[i][0], last: frames[i][frames[i].length - 1] };
  });
  return { tokens, heard, insertions, distance };
}

// words: [{ word, ipa }]. Scores one or many words in a single alignment pass.
export function scoreUtterance({ logits, T, V }, words, vocab, opts = {}) {
  const cfg = { ...DEFAULTS, ...opts };
  const blank = vocab['<pad>'] ?? 0;
  const inv = Object.fromEntries(Object.entries(vocab).map(([k, v]) => [v, k]));
  const toks = words.map(w => ({ ...w, ...tokenizeIPA(w.ipa, vocab) }));
  if (!toks.length || toks.some(t => !t.ids.length)) return { ok: false, reason: 'empty_target' };
  const ids = toks.flatMap(t => t.ids);
  const a = analyse(logSoftmax(logits, T, V), T, V, ids, blank);
  if (a.error) return { ok: false, reason: a.error };

  let k = 0;
  const out = toks.map(w => {
    const slice = a.tokens.slice(k, k + w.ids.length); k += w.ids.length;
    const phonemes = slice.map((t, i) => ({ phoneme: w.symbols[i], prob: +t.prob.toFixed(3), op: t.op }));
    const d = decide(phonemes, cfg);
    phonemes.forEach((p, i) => {
      p.status = d.statuses[i];
      const t = slice[i];
      p.saidInstead = t.op === 'sub' ? inv[t.heardId] : (p.status === 'wrong' ? inv[t.compId] : null);
    });
    return { word: w.word, target: w.symbols.join(' '), score: d.score, correct: d.correct,
             unknownTargetSymbols: w.dropped, phonemes };
  });

  const first = a.tokens[0].first, last = a.tokens[a.tokens.length - 1].last;
  const gaps = []; k = 0;
  toks.slice(0, -1).forEach(w => { k += w.ids.length; gaps.push(+((a.tokens[k].first - a.tokens[k - 1].last) * FRAME_S).toFixed(2)); });
  return {
    ok: true,
    score: Math.round(out.reduce((s, w) => s + w.score, 0) / out.length),
    correct: out.every(w => w.correct),
    words: out,
    heard: a.heard.map(i => inv[i]).join(' '),
    phonemeErrorRate: +(a.distance / ids.length).toFixed(2),
    extraSounds: a.insertions.map(i => inv[i]),
    fluency: { phonemesPerSecond: +(ids.length / ((last - first + 1) * FRAME_S)).toFixed(1), gapsSeconds: gaps,
               longPauses: gaps.filter(g => g > 0.6).length },
  };
}

// Single-word convenience wrapper (flat result).
// ipa: string OR array of accepted variants (e.g. flap [ɾ] and clear [t]). The best-matching variant wins.
export function scoreWord(out, ipa, vocab, opts = {}) {
  const variants = Array.isArray(ipa) ? ipa : [ipa];
  let best = null;
  variants.forEach((v, variant) => {
    const r = scoreUtterance(out, [{ word: '', ipa: v }], vocab, opts);
    if (!r.ok) { best ??= r; return; }
    const w = r.words[0];
    const cand = { ok: true, score: w.score, correct: w.correct, variant, target: w.target, heard: r.heard,
                   phonemeErrorRate: r.phonemeErrorRate, extraSounds: r.extraSounds,
                   unknownTargetSymbols: w.unknownTargetSymbols, phonemes: w.phonemes };
    if (!best?.ok || cand.correct > best.correct || (cand.correct === best.correct && cand.score > best.score)) best = cand;
  });
  return best;
}
