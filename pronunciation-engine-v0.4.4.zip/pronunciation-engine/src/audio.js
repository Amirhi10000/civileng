// src/audio.js — input quality gate + silence trimming. Pure functions on Float32Array (mono).
// Purpose: a bad recording must produce "try again", never a false "wrong pronunciation".

export const SR = 16000;

export function frameRms(x, win) {
  const n = Math.floor(x.length / win), out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let j = i * win; j < (i + 1) * win; j++) s += x[j] * x[j];
    out[i] = Math.sqrt(s / win);
  }
  return out;
}

export function trimSilence(x, { sr = SR, padMs = 150, relThreshold = 0.05, floor = 0.003 } = {}) {
  const win = Math.round(sr * 0.01), r = frameRms(x, win);
  const max = r.reduce((a, b) => Math.max(a, b), 0), thr = Math.max(floor, relThreshold * max);
  const a = r.findIndex(v => v > thr);
  if (a < 0) return x.slice(0, 0);
  let b = r.length - 1;
  while (b > a && r[b] <= thr) b--;
  const pad = Math.round(padMs / 10);
  return x.slice(Math.max(0, a - pad) * win, Math.min(r.length, b + 1 + pad) * win);
}

export function checkQuality(x, { sr = SR, minSec = 0.25, maxSec = 8 } = {}) {
  const sec = x.length / sr;
  let peak = 0, clip = 0;
  for (const v of x) { const a = Math.abs(v); if (a > peak) peak = a; if (a > 0.99) clip++; }
  const info = { seconds: +sec.toFixed(2), peak: +peak.toFixed(3), clipFraction: +(clip / (x.length || 1)).toFixed(4) };
  if (sec < minSec) return { ok: false, reason: 'too_short', ...info };
  if (sec > maxSec) return { ok: false, reason: 'too_long', ...info };
  if (peak < 0.02) return { ok: false, reason: 'too_quiet', ...info };
  if (info.clipFraction > 0.01) return { ok: false, reason: 'clipping', ...info };
  return { ok: true, ...info };
}
