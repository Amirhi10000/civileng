// src/worker.js — model inference off the main thread (UI never freezes). Module worker.
// All assets are LOCAL: ../vendor (transformers.js + onnx wasm) and ../models (weights). No CDN, no remote calls.
import { env, AutoModelForCTC, Tensor } from '../vendor/transformers.min.js';

const MODEL = 'Xenova/wav2vec2-lv-60-espeak-cv-ft';
env.allowRemoteModels = false;
env.allowLocalModels = true;
env.localModelPath = new URL('../models/', import.meta.url).href;
env.backends.onnx.wasm.wasmPaths = new URL('../vendor/', import.meta.url).href;

let model;
self.onmessage = async ({ data }) => {
  try {
    if (data.type === 'init') {
      model = await AutoModelForCTC.from_pretrained(MODEL, { dtype: 'q8', progress_callback: p => self.postMessage({ type: 'progress', p }) });
      const res = await fetch(`${env.localModelPath}${MODEL}/vocab.json`);
      if (!res.ok) throw new Error('vocab.json missing in models/: ' + res.status);
      self.postMessage({ type: 'ready', vocab: await res.json() });
    } else if (data.type === 'infer') {
      const { logits } = await model({ input_values: new Tensor('float32', data.x, [1, data.x.length]) });
      const [, T, V] = logits.dims, copy = Float32Array.from(logits.data);
      self.postMessage({ type: 'result', id: data.id, T, V, logits: copy }, [copy.buffer]);
    }
  } catch (e) { self.postMessage({ type: 'error', id: data.id, message: String(e?.message ?? e) }); }
};
