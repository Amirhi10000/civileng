Filled by: node tools/fetch-assets.mjs   (verify: node tools/fetch-assets.mjs --verify)
