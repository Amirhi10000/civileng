# Offline pronunciation engine v0.4.3 (PARKED until real data exists) (English for Persian speakers)

Pipeline: mic (raw capture) → quality gate → silence trim → phoneme model in a Web Worker (on-device, int8, local files only)
→ CTC forced alignment vs. the target IPA (best of the accepted variants) → per-phoneme posterior + free-decode diff
→ one decision rule (`decide()`) → Persian coaching (with a visible "unreviewed" notice) → progress tracking.

## Status — read this first
- Verified: scoring, alignment, feedback, progress and tooling logic (54 tests, synthetic data).
- NOT verified: real model output on real speech; the Worker/offline/service-worker path in a real browser; whether the model vocab contains every symbol of the lexicon (`npm run check-setup` answers this once assets exist).
- Thresholds are uncalibrated defaults. Persian coaching texts are DRAFTS: the learner sees a notice next to every tip until `REVIEW_STATUS` is changed by a reviewer.
- Model size is unmeasured here; `tools/fetch-assets.mjs` prints the real number. Decide whether it is acceptable before promising mobile/offline use.

## Layout
| Path | Purpose |
|---|---|
| src/core.js | alignment, `decide()`, word (variants) + utterance scoring, fluency |
| src/audio.js | quality gate + silence trimming |
| src/feedback-fa.js | Persian coaching (DRAFT) + learner notice |
| src/progress.js | weak-phoneme model, confusions, spaced repetition (see schedule below) |
| src/engine.js, src/worker.js | main-thread API + off-thread inference; no CDN, no remote calls; raw capture by default |
| sw.js | offline cache (untested in a real browser) |
| tools/fetch-assets.mjs | one-time model download + sha256 manifest; `--verify` |
| tools/check-setup.mjs | release gate: vendor/, models/ integrity, lexicon ⊂ model vocab |
| tools/build-lexicon.mjs | bank → target words → espeak IPA → variants |
| tools/preregister.mjs | locks Go/No-Go criteria (hash + time + git commit) |
| tools/merge-labels.mjs | two blind raters → labels, kappa, exclusion rate (stops if kappa too low) |
| tools/calibrate.mjs | thresholds from training speakers; held-out report, split by capture mode |
| tools/go-nogo.mjs | verdict on held-out speakers using the UPPER confidence bound |
| web/ | index (learner), collect (consent, audio, blocked without pre-registration), rate (blind) |

## Review schedule (matches the main system)
Failed word → tomorrow. 1st / 2nd / 3rd consecutive success → 3 / 7 / 14 days. 4th success → mastered, leaves the active queue; a later failure brings it back. Configurable: `intervalsDays`, `retryDays`.

## Calibration + Go/No-Go protocol
1. Fill `docs/go-no-go-criteria.json` (incl. min test speakers, min correct/incorrect test samples, min kappa, max excluded fraction, confidence, max false-reject/false-accept rates) → `node tools/preregister.mjs`. The collector refuses to run without a matching `docs/preregistration.json`; go-nogo refuses data recorded before registration or under a different hash.
2. `web/collect.html`: written consent, ≥ 10 Persian-speaking learners, same words, some deliberately wrong (`intent`, not the label). Collect BOTH capture modes (raw, browser-processed) so the effect of browser DSP is measured, not assumed.
3. Two raters judge blind with `web/rate.html`.
4. `node tools/merge-labels.mjs collected.json ratings-R1.json ratings-R2.json labeled.json` → also writes `labeled.meta.json` (kappa, excluded fraction). Kappa below 0.6 stops the pipeline.
5. `node tools/calibrate.mjs labeled.json --write`.
6. `node tools/go-nogo.mjs labeled.json docs/go-no-go-criteria.json docs/preregistration.json --anchor <stored value> --require-anchor [--loso]`
   - `--loso` = leave-one-speaker-out: thresholds for each speaker are chosen without that speaker; ≈ 20–25 speakers are enough to evaluate (not simulated for coverage; dependence between recordings of one speaker is still handled only by the speaker-level bounds).
   - `--require-anchor` stops the run if the external anchor is missing or does not match.
   - Verdicts: **GO** (every pre-registered check passes) · **NO-GO** (enough speakers/samples AND labels trustworthy AND the LOWER confidence bound of an error rate is above its limit: clearly bad) · **INCONCLUSIVE** (everything else, e.g. too few speakers/samples or unreliable labels — this means "not enough information", not "bad performance").
   - With a small group expect INCONCLUSIVE or a clear NO-GO; a formal GO needs many speakers. A small experiment can mainly show gross failure (the engine cannot separate correct from wrong).
Power and dependence (measured by simulation, true false-accept rate 15 %, strong speaker heterogeneity; "miss" = bound fell below the true rate, nominal 5 % at confidence 0.95):
- 30 held-out samples with zero errors still leave a 95 % upper bound of ≈ 9.5 %.
- The naive exact bound misses far more than 5 % because one speaker's recordings are not independent: 6×10 → 15 %, 10×5 → 10 %, 20×5 → 7 %, 30×5 → 12 % (noisy).
- `go-nogo` now uses the largest of: exact, speaker-level t, speaker-resampling bootstrap. That helps only a little (6×10 → 12 %, 30×5 → 9 %).
- At confidence 0.99 the misses fall to ≈ 2–3 % (nominal 1 %) for ≥ 10 speakers. Reviewers' own simulations gave different magnitudes (they depend on the assumed speaker heterogeneity, which is unknown); only the direction is reliable: more speakers and higher confidence help, per-recording counts barely do.
- CORRECTION to the earlier advice "≥ 20 test speakers": with the fixed 30 % split that needs ≈ 65 speakers in total (10 test speakers ≈ 32). For one person that is unrealistic → use `--loso`.
- Every test speaker must record BOTH correct and deliberately wrong samples; speaker-level bounds need ≥ 2 speakers per class.
Anchor: `preregister.mjs` prints an anchor string; store it outside your control (remote push / third-party email) and pass it as `--anchor` to go-nogo. Without it the pre-registration only protects against mistakes, not manipulation.
Recordings contain voices: keep only with consent; delete after calibration unless consent says otherwise.

## Offline packaging
1. Open internet machine: `node tools/fetch-assets.mjs` → `models/`.
2. `npm i @huggingface/transformers@3.0.2`; copy `dist/transformers.min.js` and the onnxruntime-web `.wasm/.mjs` files into `vendor/`.
3. `node tools/check-setup.mjs` must say "setup OK". Serve over https (or localhost).
4. Cache API storage for a model of this size may hit browser quotas; test on target phones.

## Known limits
- Word stress and intonation are not scored. Non-US accents are not yet variants.
- Lexicon IPA is from espeak-ng US-English; review rare technical words.
- Native Android/iOS: `core.js` ports directly; run the model with ONNX Runtime Mobile.

## Testing on GitHub
- `.github/workflows/ci.yml` → job `unit-tests` runs `npm test` on every push (Node 20 + 22).
- Job `real-model-check` (manual: Actions → ci → Run workflow) installs espeak-ng, downloads the real model (log shows its size), regenerates the lexicon and checks every IPA symbol against the model vocab; artifacts: `lexicon.generated.json`, `models/manifest.json`. Untested until first run on GitHub.
- Do NOT commit `models/` (files > 100 MB are rejected by plain git). Use Releases, LFS, or your own storage.
- Pushing `docs/preregistration.json` + criteria to GitHub BEFORE collecting data is a good external anchor (see protocol).
- Microphone + browser testing: GitHub Codespaces (forwarded https port) or any machine with Chrome; Actions cannot record a microphone.
