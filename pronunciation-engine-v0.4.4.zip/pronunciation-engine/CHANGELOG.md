# Changelog
## 0.4.4
- NEW GitHub Actions workflow (unit tests + manual real-model check); `check-setup --model-only`.
## 0.4.3 — fifth review (bug fixes only; module parked)
- FIX NO-GO was issued with insufficient data (2 test speakers); it now also requires every sufficiency check.
- FIX Student-t quantile is exact (the polynomial approximation was ~27 % low at df=1, ~5 % at df=2).
## 0.4.2 — fourth review
- NEW verdict INCONCLUSIVE; NO-GO now requires trustworthy labels and a LOWER bound above the limit.
- NEW `--require-anchor` (stops when the external anchor is missing/mismatching).
- NEW `--loso` leave-one-speaker-out evaluation (needs ~20–25 speakers instead of ~65).
- README corrected: the earlier "≥ 20 test speakers" advice implied ≈ 65 speakers with a 30 % split.
## 0.4.1 — third review
- Criteria ranges validated (confidence in [0.5, 0.9999], rates in [0,1], counts integer ≥ 1, minTestSpeakers ≤ minSpeakers).
- Go/No-Go bound accounts for speaker dependence (speaker-level t + speaker bootstrap, max with exact); simulated coverage documented — improvement is partial.
- Tamper-evident anchor: `preregister.mjs` prints it; `go-nogo --anchor` compares it; git commit content is verified when recorded; warnings listed.
## 0.4.0 — second review
- Learner now sees a notice that coaching is unreviewed (was only a constant).
- Go/No-Go judged on the UPPER Clopper–Pearson bound; added minTestSpeakers / minTestCorrect / minTestIncorrect / maxExcludedFraction / confidence.
- Pre-registration is enforced: hash + time + git commit; collector blocked without it; go-nogo rejects mismatching or earlier-recorded data.
- Kappa and exclusion rate come from merge-labels automatically; kappa below minimum stops the pipeline.
- Capture is RAW by default (no echo cancellation / noise suppression / AGC); mode recorded per row and reported separately.
- Review schedule matches the main system: 1d after failure; 3/7/14d after successes; 4th success = mastered.
- NEW check-setup (bundle integrity + lexicon vs model vocab), sw.js, vendor/ and models/ placeholders.
## 0.3.0 — fixes from external review
- FIX forcedAlign: repeated phonemes need an extra blank frame; short audio now returns `too_short` instead of a bogus score.
- NEW accepted pronunciation variants (flap [ɾ] / clear [t]); lexicon supports arrays; builder generates them.
- FIX Persian tip for w→v (Persian «و» is /v/); coaching marked DRAFT pending linguist review.
- FIX Leitner: failed word no longer immediately due; intervals configurable.
- CHANGE calibration protocol: consent, audio saved, speaker intent separated from rater label, blind rating page, two raters + kappa, speaker-disjoint holdout, pre-registered Go/No-Go tool.
- CHANGE runtime has no CDN/remote dependency: local vendor/ + models/, sha256 manifest, inference in a Web Worker.
- CHANGE lexicon extraction: correct answers only (or `targetWord`), max 2 words.
## 0.2.0
- Restructure; quality gate; Persian feedback; progress tracking; tools.
## 0.1.0
- First word-level scorer.
